using System;

namespace kifejezesek
{
   class Program
   {
      static void Main(string[] args)
      {
          int a=14, b=5, c, m ;
          c=a/b;
          m=a%b;
          Console.WriteLine("Eg�szoszt�s:   {0} / {1} = {2}",a,b,c);
          Console.WriteLine("Marad�kk�pz�s: {0} % {1} = {2}",a,b,m);
      }
   }
}
