using System;

namespace kifejezesek
{
   class Program
   {
      static void Main(string[] args)
      {
         int x = 10;
         int y = 3;

         int z = x + y; // �sszead�s: z = 10 + 3
         Console.WriteLine(z); // Ki�rja az eredm�nyt: 13

         z = x - y;     // Kivon�s: z = 10 - 3
         Console.WriteLine(z); // 7

         z = x * y; //Szorz�s: z = 10 * 3 
         Console.WriteLine(z);//30

         z = x / y; // Marad�k n�lk�li oszt�s: z = 10 / 3
         Console.WriteLine(z); // 3

         z = x % y; // Marad�kos oszt�s: z = 10 % 3
         Console.WriteLine(z); // Az oszt�s marad�k�t �rja ki: 1
      }
   }
}
