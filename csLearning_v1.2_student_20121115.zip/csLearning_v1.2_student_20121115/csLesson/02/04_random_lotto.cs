using System;

namespace lotto
{
   class Program
   {
       static void Main(string[] args)
       {
          int [] lotto= new int[5];
          int szam = 0;
          Random r= new Random();

          // --- 5 darab lotto sz�m el��ll�t�sa
          for (int i=0; i<5; i++)
          {
             // ---- ism�tl�d�s kiz�r�sa
             do
             {
                szam = r.Next(1, 91);
             }
             while (Array.IndexOf(lotto, szam) != -1);

             // ---- sz�mok elt�rol�sa t�mbben
             lotto[i] = szam;
         }
         // --- sz�mok rendez�se   
         Array.Sort(lotto);   

         // --- szamok kiirat�sa   
         foreach (int i in lotto)   
            Console.Write("{0}, ",i);
        }
    }
}

