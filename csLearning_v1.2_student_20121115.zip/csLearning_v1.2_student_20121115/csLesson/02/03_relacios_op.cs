using System;

namespace kifejezesek
{
   class Program
   {
      static void Main(string[] args)
      {
         int x = 10;
         int y = 23;
         Console.WriteLine(x > y); // Ki�rja az eredm�nyt: false 
         Console.WriteLine(x == y); // false
         Console.WriteLine(x != y); // x nem egyenl� y �al: true
         Console.WriteLine(x <= y); // x kisebb-egyenl� mint y: true
      }
   }
}
