/* 
 * Olvasson be egy mondatot, majd hat�rozza meg
 * a mondat karaktereinek,
 * m�ssalhangz�inak �s 
 * mag�nhangz�inak a sz�m�t. 
 * 
 * 2012.05.07 fj
 * 
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace string_mgh
{
    class Program
    {
        static void Main(string[] args)
        {

            string s, mgh;

            Console.WriteLine("K�rek egy mondatot");
            s = Console.ReadLine();

            Console.WriteLine("1) A mondat karakereinek szama: {0}", s.Length);

            mgh = "aeiou���������";
            int db_mgh = 0, db_msh = 0;

            for (int i = 0; i < s.Length; i++)
            {
                if (mgh.IndexOf(s[i]) >= 0)
                {
                    db_mgh++;
                }
                else if (" .,;:?!".IndexOf(s[i])<0)
                {
                    db_msh++;
                }
            }

            Console.WriteLine("2) A mondat maganhangzoinak a szama : {0}", db_mgh);
            Console.WriteLine("3) A mondat m�ssalhangzoinak a szama: {0}", db_msh);

            Console.WriteLine("K�rem nyomja le az ENTER-t");
            Console.ReadLine();
        }
    }
}
