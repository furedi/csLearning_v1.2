/*
Egy henger alapj�nak sugar�b�l �s magass�g�b�l
sz�m�tsuk ki a t�rfogat�t, majd hat�rozzuk meg
annak a t�glatestnek a t�rfogat�t is, amelyben
a henger �ppen elf�r! 
*/
using System;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
           Console.WriteLine("Henger �s befoglal� has�b t�rfogata\r\n");
           double r, m, vh, vt;
          
           Console.Write("Henger alapj�nak sugara:");
           r=Convert.ToDouble(Console.ReadLine());

           Console.Write("Henger magass�ga:");
           m=Convert.ToDouble(Console.ReadLine());

           vh=r*r*Math.PI*m;
           Console.WriteLine("Henger t�rfogata {0:F2}",vh);

           vt=2*r*2*r*m;
           Console.WriteLine("T�glatest t�rfogata {0:F2}",vt);

           Console.Write("\r\nK�rem nyomja le az ENTER-t!");
           Console.ReadLine();
        }
    }
}
