/*
 * Anagramma - Informatika emelt szint 2010. okt�ber 22.
 * 
 * fj
 * 
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace anagram
{
    class anagramma
    {
        System.Collections.ArrayList szavak = new System.Collections.ArrayList();

        //============================= szoveg karaktereinek sz�ma
        public void karakterek()
        {
            Console.WriteLine("\n1) K�l�nb�z� karakterek a sz�vegben");
            Console.WriteLine("Adja meg a sz�veget:");
            string s = Console.ReadLine();

            SortedSet<char> h = new SortedSet<char>();

            foreach (char c in s)
            {
                h.Add(c);
            }

            Console.WriteLine("A k�l�nb�z� karakterek sz�ma:{0}", h.Count);

            foreach (char c in h)
            {
                Console.Write("{0}, ", c);
            }
            Console.WriteLine();
        }

        //============================= sz�t�r beolvas�sa
        public void beolvas()
        {
            Console.WriteLine("\n2) szotar.txt beolvas�sa.");

            TextReader sr = new StreamReader(Environment.GetEnvironmentVariable("cslhome")+"erettsegi\\szotar.txt");
         

            string s;
            while ((s = sr.ReadLine()) != null)
            {
                szavak.Add(s);
            }

            sr.Close();
            sr = null;

            Console.WriteLine("A beolvasott szavak szama:{0}", szavak.Count);
        }

        //============================= sz�rendez�
        public string szorendezo(string a)
        {
            char c;
            StringBuilder szo = new StringBuilder();

            szo.Append(a);


            for (int i = 0; i < szo.Length-1; i++)
            {
                for (int j = i+1; j < szo.Length; j++)
                {
                    if (szo[i] > szo[j])
                    {
                        c=szo[i];
                        szo[i]=szo[j];
                        szo[j]=c;
                    }
                }
            }

            return szo.ToString();
        }

        //============================= abc.txt �r�sa
        public void abc()
        {
            Console.Write("\n3) abc.txt elk�sz�t�se");
            TextWriter sw = new StreamWriter(Environment.GetEnvironmentVariable("cslhome")+"erettsegi\\abc.txt");

            foreach (string s in szavak)
            {
                sw.WriteLine(szorendezo(s));

            }
            sw.Close();
            sw=null;
        }

        //============================= k�t sz� anagramma-e?
        public void ket_szo()
        {
            Console.WriteLine("\n4) K�t sz� anagramma-e?");
            Console.Write("Els� sz�   :");
            string szo1 = Console.ReadLine();

            Console.Write("M�sodik sz�:");
            string szo2 = Console.ReadLine();

            if (szorendezo(szo1) == szorendezo(szo2))
                Console.WriteLine("Anagramma");
            else
                Console.WriteLine("Nem anagramma");

        }

        //============================= anagramm�t keres
        public void keres()
        {
            Console.WriteLine("\n5) Sz� anagramm�i.");
            Console.Write("K�rek egy sz�t:");
            string szo = Console.ReadLine();
            int db = 0;

            foreach (string s in szavak)
            {
                if (szorendezo(szo) == szorendezo(s))
                {
                    Console.WriteLine(s);
                    db++;
                }
            }

            if (db == 0) Console.WriteLine("Nincs a sz�t�rban");

        }

        //============================= Leghosszabb sz�
        public void leghosszabb()
        {
            Console.WriteLine("\n6) Leghosszabb sz� anagramm�i.");

            int max = 0;

            foreach (string szo in szavak)
            {
                if (max < szo.Length) max = szo.Length;
            }


            //------------------------- A szavak rendezett alakj�nak kivonatolasa
            SortedSet <string> h = new SortedSet<string>();

            foreach (string szo in szavak)
	        {
                if (szo.Length == max) h.Add(szorendezo(szo));
	        }

            //------------------------- Rendezett alakhoz a szavak kikeresese
            foreach (string s in h)
            {
                foreach (string szo in szavak)
                {
                    if (s==(szorendezo(szo))) Console.WriteLine(szo);
                }
                Console.WriteLine();
            }

        }

        //============================= sz�t�r kiir�sa szavak hossza �s anagrammak szerint
        public void rendezett()
        {
            Console.WriteLine("\n7) Rendez�s szavak hossza szerint.");
            string s1 ,s2, sx ;
            for (int i = 0; i < szavak.Count-1; i++)
            {
                for (int j = i; j < szavak.Count; j++)
                {
                    s1=szavak[i].ToString();
                    s2=szavak[j].ToString();

                    if (s1.Length > s2.Length)
                    {
                        sx = szavak[i].ToString();
                        szavak[i] = szavak[j];
                        szavak[j] = sx;
                    }
                }
            }

            //foreach (string s in szavak) Console.WriteLine(s);

            StringBuilder sb = new StringBuilder();

            string aszo, szo ;
            SortedSet<string> h = new SortedSet<string>();
            szavak.Add(Convert.ToString(0xffff));

            for (int i=0; i<szavak.Count-1; i++)
            {
 
                szo = szavak[i].ToString();
                aszo = szorendezo(szo);

                if (!h.Contains(szorendezo(szo)))
                {
                    Console.Write("\n{0} ", szo);
                    if (sb.Length > 0) sb.Append("\r\n");
                    sb.Append(szo + " ");
                }

                int j = i + 1;
                while (aszo.Length==szo.Length)
                {
                    szo = szavak[j].ToString();
                    if (!h.Contains(szorendezo(szo)) && szorendezo(szo)==aszo )
                    {
                        Console.Write("{0} ", szo);
                        sb.Append(szo + " ");
                    }

                    j++;
                }
                h.Add(aszo);
            }

            TextWriter sw = new StreamWriter(Environment.GetEnvironmentVariable("cslhome")+"erettsegi\\rendezve.txt");
              sw.Write(sb);
            sw.Close();
            sw = null;
        }
    }
    
    //================================= FOPROGRAM
    class Program
    {
        static void Main(string[] args)
        {
            anagramma ana = new anagramma();

            ana.karakterek();
            ana.beolvas();
            ana.abc();
            ana.ket_szo();
            ana.keres();
            ana.leghosszabb();
            ana.rendezett();


            Console.Write("\n\nK�rem nyomja le az ENTER-t");
            Console.ReadLine();
        }
    }
}
