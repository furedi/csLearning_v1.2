/*
Olvasson be billenty�zetr�l egy mondatot! 
�rassa ki a mondat bet�it �n�ll� sorokban! 
�rassa ki mondatot szavank�nt! 
�rassa ki a mondatot ford�tva! 
�rassa ki a mondatot soronk�nt az els� karaktert�l egyes�vel n�vekv� karaktersz�mmal! 
�rassa ki a mondatot soronk�nt fogy� karaktersz�mmal!
*/

using System;

namespace I01_mondat
{
    class Program
    {
        static void Main(string[] args)
        {
           String mondat;

           Console.WriteLine("Kerek egy mondatot");
           mondat=Console.ReadLine();

           Console.WriteLine("\n------ Betuk soronkent");
           for (int i=0;i<mondat.Length;i++)
           {
              Console.WriteLine(mondat[i]);
           }

           Console.WriteLine("\n------ Szavak soronkent");
           for (int i=0;i<mondat.Length;i++)
           {
              if (mondat[i].Equals(' ')) Console.WriteLine();
              else Console.Write(mondat[i]);
           }

           Console.WriteLine("\n------ Mondat ford�tva");
           for (int i=mondat.Length-1;i>=0;i--)
           {
              Console.Write(mondat[i]);
           }
           Console.WriteLine();

           Console.WriteLine("\n------ Mondat l�pcs�zetesen");
           for (int i=1;i<=mondat.Length;i++)
              Console.WriteLine(mondat.Substring(0,i));

           Console.WriteLine("\n------ Mondat fogy� karaktersz�mmal");
           for (int i=mondat.Length;i>0;i--)
              Console.WriteLine(mondat.Substring(0,i));

           Console.WriteLine("\nK�rem nyomja le az ENTER-t");
           Console.ReadLine();

        }
    }
}

