/*
 * K�rjen be a program egy sz�veget �s egy mag�nhangz�t,
 * majd �rja ki, h�nyszor fordul el� a sz�vegben a mag�nhangz�!
 * 
 * 2012.05.07 fj
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication8
{
    class Program
    {
        static void Main(string[] args)
        {
            string s;
            char c;
            int db = 0;

            Console.WriteLine("K�rek egy mondatot");
            s=Console.ReadLine();

            Console.WriteLine("K�rek egy karaktert");
            c = Convert.ToChar(Console.ReadLine());

            for (int i = 0; i < s.Length; i++)
            {
                if (s[i] == c) db++;
            }

            Console.WriteLine("A mondatban {0} db \"{1}\" karakter van",db,c);

            Console.WriteLine("K�rem nyomja le az ENTER-t");
            Console.ReadLine();

        }
    }
}
