/*
Olvassunk be egy sz�veget �s m�g k�t karaktert!
Az els� karakter minden el�fordul�s�t
cser�lj�k ki a m�sodikra! 
*/

using System;

namespace I02_csere
{
    class Program
    {
        static void Main(string[] args)
        {
           string mondat;
           char a,b;

           Console.WriteLine("Kerek egy mondatot:");
           mondat=Console.ReadLine();

           Console.Write("Mit cser�ljek:");
           a=Convert.ToChar(Console.ReadLine());

           Console.Write("Mire cser�ljek:");
           b=Convert.ToChar(Console.ReadLine());
           
           mondat=mondat.Replace(a,b);

           Console.WriteLine(mondat);

           Console.WriteLine("\nK�rem nyomja le az ENTER-t");
           Console.ReadLine();

        }
    }
}

