/*
Olvasson be egy URL-t pl.: "http://www.iwiw.hu".
Hat�rozza meg, hogy a megjelen�t�s�hez http 
vagy ftp protokollra van sz�ks�g.
Valamint �llap�tsa meg, hogy 
milyen nemzetis�g� az oldal (.hu .de .nl) 
*/

using System;

namespace I04_substring
{
    class Program
    {
        static void Main(string[] args)
        {
           String url, protokol, topdomain;

           Console.WriteLine("Kerek egy URL-t:");
           url=Console.ReadLine();

           protokol=url.Substring(0,url.IndexOf(':'));

           Console.WriteLine("Protokol  : {0}",protokol);

           int i=url.Length-1;
           while (!url[i].Equals('.') && i>0)
           {
               i--;
           }

           topdomain=url.Substring(i,url.Length-i);

           Console.WriteLine("Top domain: {0}",topdomain);
           

           Console.WriteLine("\nK�rem nyomja le az ENTER-t");
           Console.ReadLine();

        }
    }
}

