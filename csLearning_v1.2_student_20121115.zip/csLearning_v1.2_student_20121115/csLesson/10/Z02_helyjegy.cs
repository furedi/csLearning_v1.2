/*
 * Informatika - emelet szint 2010. m�jus 11.
 * 
 * 4. feladat: helyjegy
 * Egy aut�buszokat �zemeltet� t�rsas�g t�vols�gi j�rataira az 
 * utasok jobb kiszolg�l�sa �rdek�ben csak akkor ad el jegyet,
 * ha �l�helyet is tud biztos�tani. Minden jegyre r�nyomtatja,
 * hogy az adott vonalon mett�l meddig �rv�nyes �s melyik �l�st
 * lehet elfoglalni birtok�ban...
 * 
 * 2012.03.26 fj
 * 
 * Megjegyz�s:
 * A t�mbindexel�s 0-t�l indul, ez�rt a 7. feladatn�l 
 * vigy�zni kell az �l�ssz�mokkal!
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace helyjegy
{
    class helyek
    {
        struct s_eladott
        {
            public byte ules, felszall, leszall;
        }

        int eladott_jegyek = 0;
        int vonal = 0;
        int tiz_km_ara = 0;

        s_eladott[] jegyek;

        //============================= 1) Beolvas�s
        public void beolvas()
        {
            Console.WriteLine("\n1. Olvassa be az eladott.txt �llom�nyban tal�lt adatokat!");
            try
            {
                string line;
                System.IO.TextReader readFile = new System.IO.StreamReader(Environment.GetEnvironmentVariable("cslhome")+"erettsegi\\eladott.txt");

                line = readFile.ReadLine();
                string[] words = line.Split(' ');

                eladott_jegyek = Convert.ToInt32(words[0]);
                vonal = Convert.ToInt32(words[1]);
                tiz_km_ara = Convert.ToInt32(words[2]);

                jegyek = new s_eladott[eladott_jegyek];

                int i = -1;
                while ((line = readFile.ReadLine()) != null)
                {
                    words = line.Split(' ');

                    i++;
                    jegyek[i].ules = Convert.ToByte(words[0]);
                    jegyek[i].felszall = Convert.ToByte(words[1]);
                    jegyek[i].leszall = Convert.ToByte(words[2]);

                }
                readFile.Close();
                readFile = null;
                Console.WriteLine("Beolvasott adatoksorok szama: {0}", i+1);
            }
            catch (System.IO.IOException ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }

        //============================= 2) Legutolso jegy
        public void legutolso()
        {
                   
            Console.WriteLine("\n2. Adja meg a legutols� jegyv�s�rl� �l�s�nek sorsz�m�t �s az �ltala beutazott t�vols�got!");

            Console.WriteLine("�l�s:{0}   T�vols�g:{1}", jegyek[eladott_jegyek-1].ules, jegyek[eladott_jegyek-1].leszall - jegyek[eladott_jegyek-1].felszall);
        }

        //============================= 3) Teljes �t
        public void teljesut()
        {
            Console.WriteLine("\n3. List�zza ki, kik utazt�k v�gig a teljes utat! (sz�moz�s 1-t�l)");

            for (int i = 0; i < jegyek.Length; i++)
            {
                if (jegyek[i].leszall - jegyek[i].felszall == vonal)
                {
                    // i+1 => utasok sz�moz�sa 1-t�l induljon
                    Console.Write("{0} ", i+1);
                }
            }
            Console.WriteLine();
        }

        //============================= 4) Bev�tel
        public void bevetel()
        {
            Console.WriteLine("\n4. Hat�rozza meg, hogy a jegyekb�l mennyi bev�tele sz�rmazott a t�rsas�gnak!");
            int jegyar = 0, maradek = 0;
            int osszesen = 0;
            for (int i = 0; i < jegyek.Length; i++)
            {
                jegyar = (jegyek[i].leszall - jegyek[i].felszall) * tiz_km_ara;
                //Console.Write("{0} ",jegyar);
                maradek = jegyar % 10;
                if (maradek == 1 || maradek == 2) jegyar -= maradek;
                else if (maradek == 6 || maradek == 7) jegyar -= maradek - 5;
                else if (maradek == 3 || maradek == 4) jegyar += 5 - maradek;
                else if (maradek == 8 || maradek == 9) jegyar += 10 - maradek;

                //Console.Write(jegyar);
                //Console.ReadLine();

                osszesen += jegyar;
            }
            Console.WriteLine("Bevetel = {0} ", osszesen);

        }

        //============================= 5) v�g�llom�s el�tt
        public void vegelott()
        {
                   Console.WriteLine("\n5. A busz v�g�llom�st megel�z� utols� meg�ll�sn�l h�nyan sz�lltak fel �s le?");
            int max2 = 0;

            for (int i = 0; i < jegyek.Length; i++)
            {
                if (max2 < jegyek[i].leszall && jegyek[i].leszall != vonal)
                {
                    max2 = jegyek[i].leszall;
                }
            }

            int fel = 0, le = 0;
            for (int i = 0; i < jegyek.Length; i++)
            {
                if (jegyek[i].felszall == max2) fel++;
                if (jegyek[i].leszall == max2) le++;
            }

            Console.WriteLine("Az utolso el�tti meg�ll� {0} km, felsz�ll� {1}, lesz�ll� {2}", max2, fel, le);

        }

        //============================= 6) meg�ll�k sz�ma
        public void megallok()
        {
            Console.WriteLine("\n6. H�ny helyen �llt meg a busz a kiindul� �s a c�l�llom�sok k�z�tt?");
            List<byte> megallo = new List<byte>();

            for (int i = 0; i < jegyek.Length; i++)
            {
                if (!megallo.Contains(jegyek[i].felszall)) megallo.Add(jegyek[i].felszall);
                if (!megallo.Contains(jegyek[i].leszall)) megallo.Add(jegyek[i].leszall);
            }

            int megallo_db = 0;
            foreach (byte item in megallo)
            {
                if (item != 0 && item != vonal) megallo_db++;
            }
            Console.WriteLine("Meg�ll�k sz�ma: {0}", megallo_db);
        }

        //============================= 7) utaslista
        public void utaslista()
        {
            Console.WriteLine("\n7. K�sz�tsen utaslist�t az �t egy adott pontj�r�l");
            int[] ulesek = new int[48];  // --- Elemek 0-t�l 47-ig szamozva !!!
            byte pont = 0;

            Console.Write("Kiindul�st�l val� t�vols�g (max:{0}):", vonal);
            pont = Convert.ToByte(Console.ReadLine());

            for (int i = 0; i < jegyek.Length; i++)
            {
                //Console.Write("{0} {1} {2}",jegyek[i].ules,jegyek[i].felszall, jegyek[i].leszall);
                if (jegyek[i].felszall <= pont && jegyek[i].leszall > pont)
                {
                    /* 
                     * jegyek[i].ules-1 => a 48. hely �gy itt a 47. lesz (0-47)!!!
                     * 
                     * i + 1 => az utasok sz�m�t 0-t�l jegyek-1 sz�moztuk,
                     *          de a, kiirasn�l 1-t�l jegyek-ig lesznek sz�mozva.
                     */
               
                    ulesek[jegyek[i].ules-1] = i+1;
                    
                    //Console.Write(" -> {0} =>{1} {2}", i,jegyek[i].ules, ulesek[jegyek[i].ules-1]);
                }
                //Console.WriteLine();
            }

            try
            {
                System.IO.TextWriter tw = new System.IO.StreamWriter(Environment.GetEnvironmentVariable("cslhome")+"erettsegi\\kihol.txt");
                for (int i = 0; i < ulesek.Length; i++)
                {
                    if (ulesek[i]>0)
                        // --- i+1 => az ulesek sz�m�t 0-tol 47-ig sz�moztuk
                        //            de �gy 1-t�l 48-ig jelen�tj�k meg !!!
                        tw.WriteLine("{0}. �l�s: {1}. utas", i + 1, ulesek[i]); 
                    else
                       tw.WriteLine("{0}. �l�s: �res", i + 1);
                }
                tw.Close();
                tw = null;
                Console.WriteLine("Eredm�ny a kihol.txt f�jlban.");
            }
            catch (System.IO.IOException ex)
            {
                Console.WriteLine(ex.ToString());
            }

        }

    } //------------------------------- End of class helyek

    //================================= FOPROGRAM
    class Program
    {
         static void Main(string[] args)
        {

            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Clear();

            helyek h = new helyek();

            Console.WriteLine("Helyjegy: Informatika-emelt szint 2010. m�jus 11.");

            h.beolvas();

            h.legutolso();

            h.teljesut();

            h.bevetel();

            h.vegelott();

            h.megallok();

            h.utaslista();

            //------------------------- Kil�p�sre v�rakoz�s
            Console.Write("\nKerem nyomja le az ENTER-t");
            Console.ReadLine();
        }
    }
}
