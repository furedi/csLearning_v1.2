﻿/*
 * A mintaprogram a DataGridView Control futásidejű kezelését mutatja be. 
 *
 * A forráskód mérete nagyobb 32 kB-nál, ezért a textBox-ban már nem szerkeszthető.
 *
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ControllersDemo1
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }

    public class Form1 : Form
    {
        public enum Felsorol
        {
            Elso,
            Masodik,
            Harmadik,
            Negyedik,
            Ötödik
        }

        private Random rnd;

        public Form1()
        {
            rnd = new Random();
            InitializeComponent();
            CreateSampleColumns();
            resizeableColumnsCheckBox.Checked = true;
            resizeableRowsCheckBox.Checked = true;
            multiSelectCheckBox.Checked = true;

            //adding sample rows
            dgv1.Rows.Add(CreateSampleRow());
            dgv1.Rows.Add(CreateSampleRow());
            dgv1.Rows.Add(CreateSampleRow());
            dgv1.Rows.Add(CreateSampleRow());
            dgv1.Rows.Add(CreateSampleRow());
            dgv1.Rows.Add(CreateSampleRow());
            dgv1.Rows.Add(CreateSampleRow());
        }

        private void CreateSampleColumns()
        {
            DataGridViewColumn tmpCol = new DataGridViewCheckBoxColumn();
            tmpCol.HeaderText = "CheckBox1";
            tmpCol.Width = 70;
            dgv1.Columns.Add(tmpCol);

            tmpCol = new DataGridViewTextBoxColumn();
            tmpCol.HeaderText = "Textbox1";
            tmpCol.Width = 70;
            dgv1.Columns.Add(tmpCol);

            tmpCol = new DataGridViewImageColumn();
            tmpCol.HeaderText = "Image1";
            tmpCol.Width = 40;
            dgv1.Columns.Add(tmpCol);

            tmpCol = new DataGridViewComboBoxColumn();
            tmpCol.HeaderText = "ComboBox1";
            tmpCol.Width = 120;
            dgv1.Columns.Add(tmpCol);

            tmpCol = new DataGridViewLinkColumn();
            tmpCol.HeaderText = "Link1";
            tmpCol.Width = 120;
            dgv1.Columns.Add(tmpCol);

            tmpCol = new DataGridViewButtonColumn();
            tmpCol.HeaderText = "Button1";
            tmpCol.Width = 80;
            dgv1.Columns.Add(tmpCol);
        }

        private DataGridViewCell FillCell(DataGridViewColumn col)
        {
            DataGridViewCell c;
            //Button
            if (col is DataGridViewButtonColumn)
            {
                c = new DataGridViewButtonCell();
                (c as DataGridViewButtonCell).Value = "Button" + rnd.Next(1, 10);
            }
            //checkbox
            else if (col is DataGridViewCheckBoxColumn)
            {
                c = new DataGridViewCheckBoxCell();
                (c as DataGridViewCheckBoxCell).Value = rnd.Next(0, 2) > 0 ? true : false;
            }
            //combobox
            else if (col is DataGridViewComboBoxColumn)
            {
                c = new DataGridViewComboBoxCell();
                (c as DataGridViewComboBoxCell).Items.Add("Első");
                (c as DataGridViewComboBoxCell).Items.Add("Második");
                (c as DataGridViewComboBoxCell).Items.Add("Harmadik");
            }
            //image
            else if (col is DataGridViewImageColumn)
            {
                c = new DataGridViewImageCell();
                string filePath = Environment.GetEnvironmentVariable("cslhome")+"pictures\\bird" + Convert.ToString(rnd.Next(1, 4)) + ".ico";
                //string filePath = @"Images\icon" + rnd.Next(1, 4) + ".ico";
                if (System.IO.File.Exists(filePath))
                {
                    Icon ic = new Icon(filePath);
                    (c as DataGridViewImageCell).Value = ic;
                }
            }
            //link
            else if (col is DataGridViewLinkColumn)
            {
                c = new DataGridViewLinkCell();
                c.ToolTipText = "A link megnyitásához kattintson ide.";
                (c as DataGridViewLinkCell).Value = rnd.Next(0, 2) > 0 ? "www.google.hu" : "www.bing.com";
            }
            //TextBox
            else if (col is DataGridViewTextBoxColumn)
            {
                c = new DataGridViewTextBoxCell();
                c.Value = "sample text";
            }
            //general column
            else
            {
                c = new DataGridViewTextBoxCell();
            }

            return c;
        }

        private DataGridViewRow CreateSampleRow()
        {
            DataGridViewRow result = new DataGridViewRow();
            foreach (DataGridViewColumn col in dgv1.Columns)
            {
                result.Cells.Add(FillCell(col));
            }
            return result;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            AddNewColumnForm tmpForm = new AddNewColumnForm();
            if (tmpForm.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                DataGridViewColumn tmpCol;
                switch (tmpForm.tipus)
                {
                    case "Button":
                        {
                            tmpCol = new DataGridViewButtonColumn();
                            break;
                        }
                    case "CheckBox":
                        {
                            tmpCol = new DataGridViewCheckBoxColumn();
                            break;
                        }
                    case "ComboBox":
                        {
                            tmpCol = new DataGridViewComboBoxColumn();
                            break;
                        }
                    case "Image":
                        {
                            tmpCol = new DataGridViewImageColumn();
                            break;
                        }
                    case "Link":
                        {
                            tmpCol = new DataGridViewLinkColumn();
                            break;
                        }
                    case "TextBox":
                        {
                            tmpCol = new DataGridViewTextBoxColumn();
                            break;
                        }
                    default:
                        {
                            tmpCol = new DataGridViewColumn();
                            break;
                        }
                }
                tmpCol.HeaderText = tmpForm.oszlopNev;
                tmpCol.MinimumWidth = 40;
                tmpCol.Width = 60;
                dgv1.Columns.Add(tmpCol);

                //fill new column with values
                for (int i = 0; i < dgv1.Rows.Count; i++)
                {
                    dgv1.Rows[i].Cells[dgv1.Columns.Count - 1] = FillCell(tmpCol);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewColumn c in dgv1.SelectedColumns)
            {
                dgv1.Columns.Remove(c);
            }
        }

        private void radioButtons_Click(object sender, EventArgs e)
        {
            switch (((RadioButton)sender).Text)
            {
                case "Cella":
                    {
                        dgv1.SelectionMode = DataGridViewSelectionMode.CellSelect;
                        foreach (DataGridViewColumn c in dgv1.Columns)
                        {
                            c.SortMode = DataGridViewColumnSortMode.Automatic;
                        }
                        break;
                    }
                case "Teljes sor":
                    {
                        dgv1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                        foreach (DataGridViewColumn c in dgv1.Columns)
                        {
                            c.SortMode = DataGridViewColumnSortMode.Automatic;
                        }
                        break;
                    }
                case "Teljes oszlop":
                    {
                        //Szükséges a rendezhetőség kikapcsolása, különben exceptiont dob oszlopkijelölésre
                        foreach (DataGridViewColumn c in dgv1.Columns)
                        {
                            c.SortMode = DataGridViewColumnSortMode.NotSortable;
                        }
                        dgv1.SelectionMode = DataGridViewSelectionMode.FullColumnSelect;
                        break;
                    }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
			DataGridViewRow newRow = CreateSampleRow();
            dgv1.Rows.Add(newRow);
        }

        private void removeRowButton_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow r in dgv1.SelectedRows)
            {
                dgv1.Rows.Remove(r);
            }
        }

        private void CustomColOrderCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            dgv1.AllowUserToOrderColumns = CustomColOrderCheckBox.Checked;
        }

        private void writeOnlyCellsCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            dgv1.ReadOnly = writeOnlyCellsCheckBox.Checked;
        }

        private void resizeableColumnsCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            dgv1.AllowUserToResizeColumns = resizeableColumnsCheckBox.Checked;
        }

        private void resizeableRowsCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            dgv1.AllowUserToResizeRows = resizeableRowsCheckBox.Checked;
        }

        private void onLink2Click(object sender, EventArgs e)
        {
            MessageBox.Show("onLink2");
        }

        private void onLinkClick(object sender, DataGridViewCellEventArgs e)
        {
            MessageBox.Show(dgv1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString());
        }

        private void multiSelectCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            dgv1.MultiSelect = multiSelectCheckBox.Checked;
        }

        private void dgv1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0) return;
            if (dgv1.Columns[e.ColumnIndex] is DataGridViewButtonColumn)
            {
                MessageBox.Show(String.Format("{0} megnyomva.", dgv1[e.ColumnIndex, e.RowIndex].Value));
            }
            else if (dgv1.Columns[e.ColumnIndex] is DataGridViewLinkColumn)
            {
                System.Diagnostics.Process.Start(dgv1[e.ColumnIndex, e.RowIndex].Value.ToString());
            }

        }

        //Visual Studio generated content

        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgv1 = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.removeRowButton = new System.Windows.Forms.Button();
            this.addRowButton = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.CustomColOrderCheckBox = new System.Windows.Forms.CheckBox();
            this.writeOnlyCellsCheckBox = new System.Windows.Forms.CheckBox();
            this.resizeableColumnsCheckBox = new System.Windows.Forms.CheckBox();
            this.resizeableRowsCheckBox = new System.Windows.Forms.CheckBox();
            this.multiSelectCheckBox = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgv1)).BeginInit();
            this.panel1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgv1
            // 
            this.dgv1.AllowUserToAddRows = false;
            this.dgv1.AllowUserToDeleteRows = false;
            this.dgv1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv1.Location = new System.Drawing.Point(120, 0);
            this.dgv1.Name = "dgv1";
            this.dgv1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgv1.Size = new System.Drawing.Size(613, 474);
            this.dgv1.TabIndex = 0;
            this.dgv1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv1_CellContentClick);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.groupBox4);
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(120, 474);
            this.panel1.TabIndex = 1;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.removeRowButton);
            this.groupBox3.Controls.Add(this.addRowButton);
            this.groupBox3.Location = new System.Drawing.Point(4, 4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(113, 76);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Sorkezelés:";
            // 
            // removeRowButton
            // 
            this.removeRowButton.Location = new System.Drawing.Point(18, 46);
            this.removeRowButton.Name = "removeRowButton";
            this.removeRowButton.Size = new System.Drawing.Size(75, 23);
            this.removeRowButton.TabIndex = 3;
            this.removeRowButton.Text = "Törlés";
            this.removeRowButton.UseVisualStyleBackColor = true;
            this.removeRowButton.Click += new System.EventHandler(this.removeRowButton_Click);
            // 
            // addRowButton
            // 
            this.addRowButton.Location = new System.Drawing.Point(18, 17);
            this.addRowButton.Name = "addRowButton";
            this.addRowButton.Size = new System.Drawing.Size(75, 23);
            this.addRowButton.TabIndex = 2;
            this.addRowButton.Text = "Hozzáadás";
            this.addRowButton.UseVisualStyleBackColor = true;
            this.addRowButton.Click += new System.EventHandler(this.button4_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radioButton3);
            this.groupBox2.Controls.Add(this.radioButton2);
            this.groupBox2.Controls.Add(this.radioButton1);
            this.groupBox2.Location = new System.Drawing.Point(4, 171);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(113, 95);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Kijelölési mód:";
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(7, 68);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(86, 17);
            this.radioButton3.TabIndex = 2;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "Teljes oszlop";
            this.radioButton3.UseVisualStyleBackColor = true;
            this.radioButton3.Click += new System.EventHandler(this.radioButtons_Click);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(7, 44);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(70, 17);
            this.radioButton2.TabIndex = 1;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Teljes sor";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.Click += new System.EventHandler(this.radioButtons_Click);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(7, 20);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(48, 17);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Cella";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.Click += new System.EventHandler(this.radioButtons_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Location = new System.Drawing.Point(3, 86);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(114, 78);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Oszlopkezelés";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(20, 48);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 1;
            this.button2.Text = "Törlés";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(20, 19);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "Hozzáadás";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.multiSelectCheckBox);
            this.groupBox4.Controls.Add(this.resizeableRowsCheckBox);
            this.groupBox4.Controls.Add(this.resizeableColumnsCheckBox);
            this.groupBox4.Controls.Add(this.writeOnlyCellsCheckBox);
            this.groupBox4.Controls.Add(this.CustomColOrderCheckBox);
            this.groupBox4.Location = new System.Drawing.Point(4, 273);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(110, 198);
            this.groupBox4.TabIndex = 4;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Működés:";
            // 
            // CustomColOrderCheckBox
            // 
            this.CustomColOrderCheckBox.AutoSize = true;
            this.CustomColOrderCheckBox.Location = new System.Drawing.Point(7, 20);
            this.CustomColOrderCheckBox.Name = "CustomColOrderCheckBox";
            this.CustomColOrderCheckBox.Size = new System.Drawing.Size(91, 30);
            this.CustomColOrderCheckBox.TabIndex = 0;
            this.CustomColOrderCheckBox.Text = "Cserélhető\r\noszlopsorrend";
            this.CustomColOrderCheckBox.UseVisualStyleBackColor = true;
            this.CustomColOrderCheckBox.CheckedChanged += new System.EventHandler(this.CustomColOrderCheckBox_CheckedChanged);
            // 
            // writeOnlyCellsCheckBox
            // 
            this.writeOnlyCellsCheckBox.AutoSize = true;
            this.writeOnlyCellsCheckBox.Location = new System.Drawing.Point(7, 55);
            this.writeOnlyCellsCheckBox.Name = "writeOnlyCellsCheckBox";
            this.writeOnlyCellsCheckBox.Size = new System.Drawing.Size(73, 30);
            this.writeOnlyCellsCheckBox.TabIndex = 1;
            this.writeOnlyCellsCheckBox.Text = "Írásvédett\r\nmezők";
            this.writeOnlyCellsCheckBox.UseVisualStyleBackColor = true;
            this.writeOnlyCellsCheckBox.CheckedChanged += new System.EventHandler(this.writeOnlyCellsCheckBox_CheckedChanged);
            // 
            // resizeableColumnsCheckBox
            // 
            this.resizeableColumnsCheckBox.AutoSize = true;
            this.resizeableColumnsCheckBox.Location = new System.Drawing.Point(7, 90);
            this.resizeableColumnsCheckBox.Name = "resizeableColumnsCheckBox";
            this.resizeableColumnsCheckBox.Size = new System.Drawing.Size(94, 30);
            this.resizeableColumnsCheckBox.TabIndex = 2;
            this.resizeableColumnsCheckBox.Text = "Átméretezhető\r\noszlopok";
            this.resizeableColumnsCheckBox.UseVisualStyleBackColor = true;
            this.resizeableColumnsCheckBox.CheckedChanged += new System.EventHandler(this.resizeableColumnsCheckBox_CheckedChanged);
            // 
            // resizeableRowsCheckBox
            // 
            this.resizeableRowsCheckBox.AutoSize = true;
            this.resizeableRowsCheckBox.Location = new System.Drawing.Point(7, 125);
            this.resizeableRowsCheckBox.Name = "resizeableRowsCheckBox";
            this.resizeableRowsCheckBox.Size = new System.Drawing.Size(94, 30);
            this.resizeableRowsCheckBox.TabIndex = 3;
            this.resizeableRowsCheckBox.Text = "Átméretezhető\r\nsorok";
            this.resizeableRowsCheckBox.UseVisualStyleBackColor = true;
            this.resizeableRowsCheckBox.CheckedChanged += new System.EventHandler(this.resizeableRowsCheckBox_CheckedChanged);
            // 
            // multiSelectCheckBox
            // 
            this.multiSelectCheckBox.AutoSize = true;
            this.multiSelectCheckBox.Location = new System.Drawing.Point(7, 160);
            this.multiSelectCheckBox.Name = "multiSelectCheckBox";
            this.multiSelectCheckBox.Size = new System.Drawing.Size(81, 30);
            this.multiSelectCheckBox.TabIndex = 4;
            this.multiSelectCheckBox.Text = "Többszörös\r\nkijelölés";
            this.multiSelectCheckBox.UseVisualStyleBackColor = true;
            this.multiSelectCheckBox.CheckedChanged += new System.EventHandler(this.multiSelectCheckBox_CheckedChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(733, 474);
            this.Controls.Add(this.dgv1);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "DataGridView Demo";
            ((System.ComponentModel.ISupportInitialize)(this.dgv1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button removeRowButton;
        private System.Windows.Forms.Button addRowButton;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.CheckBox CustomColOrderCheckBox;
        private System.Windows.Forms.CheckBox writeOnlyCellsCheckBox;
        private System.Windows.Forms.CheckBox resizeableColumnsCheckBox;
        private System.Windows.Forms.CheckBox resizeableRowsCheckBox;
        private System.Windows.Forms.CheckBox multiSelectCheckBox;

    }

    public class AddNewColumnForm : Form
    {
        public string oszlopNev { get; protected set; }
        public string tipus { get; protected set; }


        public AddNewColumnForm()
        {
            InitializeComponent();
        }

        private void okButton_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length < 1)
            {
                MessageBox.Show("Az új oszlop neve nem lehet üres.", "Hiba!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            this.DialogResult = DialogResult.OK;
            oszlopNev = textBox1.Text;
            tipus = typeBox.SelectedItem.ToString();
            this.Close();
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {

        }

        private void AddNewColumnForm_Load(object sender, EventArgs e)
        {
            typeBox.SelectedIndex = 5;
        }

        //VS generated
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.okButton = new System.Windows.Forms.Button();
            this.cancelButton = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.typeBox = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // okButton
            // 
            this.okButton.Location = new System.Drawing.Point(3, 3);
            this.okButton.Name = "okButton";
            this.okButton.Size = new System.Drawing.Size(75, 23);
            this.okButton.TabIndex = 0;
            this.okButton.Text = "Hozzáad";
            this.okButton.UseVisualStyleBackColor = true;
            this.okButton.Click += new System.EventHandler(this.okButton_Click);
            // 
            // cancelButton
            // 
            this.cancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cancelButton.Location = new System.Drawing.Point(84, 3);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(75, 23);
            this.cancelButton.TabIndex = 1;
            this.cancelButton.Text = "Mégse";
            this.cancelButton.UseVisualStyleBackColor = true;
            this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.okButton);
            this.panel1.Controls.Add(this.cancelButton);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 64);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(208, 30);
            this.panel1.TabIndex = 3;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(79, 10);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(121, 20);
            this.textBox1.TabIndex = 4;
            // 
            // typeBox
            // 
            this.typeBox.FormattingEnabled = true;
            this.typeBox.Items.AddRange(new object[] {
            "Button",
            "CheckBox",
            "ComboBox",
            "Image",
            "Link",
            "TextBox"});
            this.typeBox.Location = new System.Drawing.Point(79, 36);
            this.typeBox.Name = "typeBox";
            this.typeBox.Size = new System.Drawing.Size(121, 21);
            this.typeBox.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Oszlopnév:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Oszloptípus:";
            // 
            // AddNewColumnForm
            // 
            this.AcceptButton = this.okButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.cancelButton;
            this.ClientSize = new System.Drawing.Size(208, 94);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.typeBox);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "AddNewColumnForm";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Új oszlop hozzáadása";
            this.Load += new System.EventHandler(this.AddNewColumnForm_Load);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button okButton;
        private System.Windows.Forms.Button cancelButton;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ComboBox typeBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }

}
