/*
 * Sz�m�tsa ki az �e� sz�m �rt�k�t! Az �rt�k meghat�roz�s�hoz az 
 * e=(1+1/n)^n n>=1 sorozat �rt�keit kell kisz�m�tani.
 * A sz�m�t�st addig folytassa, m�g k�t egym�st k�vet� kisz�m�tott
 * elem k�l�nbs�ge abszol�t �rt�kben kisebb, mint 0,00000001.
 * A hatv�ny kisz�m�t�s�hoz haszn�ljon ciklust!
 *
 * 2012.10.25 fj
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace szpgy2_5_1
{
    class Szamitas
    {
        private double e = 0;

        public double gete()
        {
            //----- Sorozat elso elem�nek kisz�m�t�sa
            double n = 1;
            e=Math.Pow((1+1/n),n);

            //----- Sorozat k�vetkez� elemeinek kisz�m�t�sa
            n++;
            while (Math.Pow((1+1/n),n)-e>0.00000001)
            {
                e=Math.Pow((1+1/n),n);
                n++;
            }

            return e;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Szamitas num = new Szamitas();

            Console.WriteLine("Sorozat �rt�keivel   e= {0:F8}", num.gete());
            Console.WriteLine("A Math.E f�ggv�nnyel e= {0:F8}", Math.E);
            
        }
    }
}