/*
 * Olvassunk be pozit�v eg�sz sz�mokat, �s 
 * �rjuk ki a sz�m 16-os sz�mrendszerbeli alakj�t.
 * A 0 (nulla) beolvas�s�ra �lljon le a program.
 *
 * 2012.10.19 fj
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace szgpr2_4_3
{
    class Hexadecimalis
    {
        public string ToHexadec(int szam)
        {
            string szamjegyek = "0123456789ABCDEF";
            string hdszam="";
            
            do
            {
                hdszam=szamjegyek[szam % 16]+hdszam;
                szam = szam / 16;
            } while (szam > 0);

            return hdszam;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Pozit�v eg�sz sz�m �talak�t�sa 16-os sz�mrendszerbe (Kil�p�shez 0)");

            Hexadecimalis hd = new Hexadecimalis();

            int a;
            do
            {
                Console.Write("\na=");
                a = int.Parse(Console.ReadLine());

                Console.WriteLine("0x"+hd.ToHexadec(a));

            } while (a > 0);

        }
    }
}