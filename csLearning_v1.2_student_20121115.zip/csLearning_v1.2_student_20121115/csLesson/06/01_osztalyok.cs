/*
 * K�sz�ts�nk objektumot egy k�r adatainak kezel�s�hez, majd
 * sz�rmaztassunk bel�le egy henger objektumot.
 *
 * Figyelj�k meg az objektum deklar�ci�t, az �r�kl�d�st!
 * 
 */
using System;

namespace objektumok
{
   //================================== Circle oszt�ly
    public class circle
    {
        //----------------------------- Mez�k
        protected double x_koordinata;
        protected double y_koordinata;
        protected double r_sugar;

        //----------------------------- Tulajdons�gok
        public double x
        {
            get
            {
                return x_koordinata;
            }
            set
            {
                x_koordinata = value;
            }
        }

        public double y
        {
            get
            {
                return y_koordinata;
            }
            set
            {
                y_koordinata = value;
            }
        }

        public double r
        {
            get
            {
                return r_sugar;
            }
            set
            {
                r_sugar = value;
            }
        }
        //----------------------------- Metodusok
        public double kerulet()
        {
            return 2*r_sugar*Math.PI;
        }
        public double terulet()
        {
            return Math.Pow(r_sugar,2)*Math.PI;
        }

    } //--- circle oszt�ly v�ge

   //================================== Cylinder oszt�ly
    public class cylinder : circle
    {
        //----------------------------- Mez�k
        private double h_magassag;

        //----------------------------- Tulajdons�gok
        public double h
        {
            get
            {
                return h_magassag;
            }
            set
            {
                h_magassag = value;
            }
        }
        //----------------------------- Metodusok
        public double felszin()
        {
            return 2*Math.Pow(r_sugar,2)*Math.PI+2*r_sugar*Math.PI*h_magassag;
        }
        public double terfogat()
        {
            return h*Math.Pow(r_sugar,2)*Math.PI;
        }
    }
    //================================= FOPROGRAM
    class Program
    {
        static void Main(string[] args)
        {
            //------------------------- A circle oszt�ly p�ld�nyos�t�sa
            circle kor = new circle();

            kor.x = 10;      // --- Bels� �rt�kad�s
            kor.y = 50;
            kor.r = 20;

            //------------------------- A cylinder oszt�ly p�ld�nyos�t�sa
            cylinder henger = new cylinder();

            henger.x = 70;   // --- Bels� �rt�kad�s
            henger.y = 80;
            henger.r = 40;
            henger.h = 100;

            Console.WriteLine("Oszt�lyok haszn�lata");

            Console.WriteLine("\r\nA k�r k�z�ppontja {0},{1} -> sugara {2} egys�g.",kor.x,kor.y,kor.r);

            Console.WriteLine("ker�let={0,12:0.00}",kor.kerulet());
            Console.WriteLine("Ter�let={0,12:0.00}",kor.terulet());

            Console.WriteLine("\r\nA henger alapk�r�nek k�z�ppontja {0},{1} -> sugara {2} egys�g.",henger.x,henger.y,henger.r);
            Console.WriteLine("A henger magass�ga {0} egyseg.",henger.h);
            Console.WriteLine("Felsz�n ={0,12:0.00}",henger.felszin());
            Console.WriteLine("T�rfogat={0,12:0.00}",henger.terfogat());
        }
    }
}
