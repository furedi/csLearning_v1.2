/*
 * �rjon programot, amely egy x term�szetes sz�mb�l, �s egy epszilon
 * hibakorl�tb�l kisz�m�tja e^x -t a k�vetkez� sor seg�ts�g�vel:
 * e^x = 1 + x + x^2/2! + x^3/3! +... 
 * Az �sszeget addig sz�molja, am�g az utols� tag abszol�t �rt�ke 
 * kisebb nem lesz egy adott epszilonn�l.
 * A k�vetkez� tagot, teh�t a sz�ml�l�t �s a nevez�t is az el�z� tagb�l sz�molja ki.
 * Mivel ez k�zel�t�s, �rja ki a k�zel�t�sek sz�m�t is.
 *
 * 2012.10.26 fj
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace szpgy2_5_4
{
    class Szamok
    {
        public double e_x(uint x, double epszilon, ref uint i)
        {
            //--- Munkav�ltoz�k deklar�l�sa, kezd��rt�kad�s
            double hatvany = 1;
            double faktorialis = 1;
            double sorozat=1;

            //--- e^x kisz�m�t�sa a hatv�ny �s a faktori�lis sorozatb�l
            i=1;
            while (Math.Abs(hatvany/faktorialis)>epszilon)
            {
                hatvany*=x;
                faktorialis *= i;
                sorozat += hatvany / faktorialis;
                i++;
            }
            return sorozat;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("e ^ x kisz�m�t�sa");

            Szamok f = new Szamok();
            
            Console.Write("\nx=");
            uint  x = uint.Parse(Console.ReadLine());

            double epszilon = 1.0E-30;
            uint db = 0;

            Console.WriteLine("\n{0} ^ {1} = {2} (K�zel�t�sek sz�ma: {3})",
                               Math.E, x, f.e_x(x,epszilon,ref db),db);

            Console.WriteLine("\n{0} ^ {1} = {2} (Math.Pow f�gv�nnyel)",
                               Math.E, x, Math.Pow(Math.E,x));

            //------------------------- Kil�p�sre v�rakoz�s
            Console.Write("\nKerem nyomja le az ENTER-t");
            Console.ReadLine();
        }
    }
}