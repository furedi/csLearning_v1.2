/*
 * Sz�m�tsa ki egy sz�m n�gyzetgy�k�t Newton m�dszerrel.
 * A beolvasott sz�m legyen A. X1=A/2, Xn+1=(Xn+A/Xn)/2 ha n>=1.
 * A sz�m�t�st addig folytassa, am�g |Xn+1-Xn|<0,0001. 
 * Az eredm�nyt n�gy tizedes jegyre jelen�tse meg!
 *
 * 2012.10.19 fj
 */


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace negyzetgyok_newton
{

    class Negyzetgyok
    {
        public double szamol(double szam)
        {
            double x = szam / 2;

            while (Math.Abs(x - (x + szam / x) / 2) > 0.0000001)
            {
                x = (x + szam / x) / 2;
            }
            return x;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Sz�m n�gyzetgy�k�nek kisz�m�t�sa Newton m�dszerrel.");

            Negyzetgyok ngy = new Negyzetgyok();

            Console.Write("\na=");
            double a = double.Parse(Console.ReadLine());

            Console.WriteLine("\n{0} negyzetgyoke {1}", a, ngy.szamol(a));

            //------------------------- Kil�p�sre v�rakoz�s
            Console.Write("\nKerem nyomja le az ENTER-t");
            Console.ReadLine();
        }
    }
}
