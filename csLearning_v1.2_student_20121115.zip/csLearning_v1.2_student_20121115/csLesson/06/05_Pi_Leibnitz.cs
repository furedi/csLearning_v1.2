/*
 * Sz�m�tsa ki Pi �rt�k�t a k�vetkez� (Leibnitz-f�le) sorral
 * 6 tizedesjegy pontoss�ggal: Pi = 4 * (1 - 1/3 + 1/5 - 1/7 + �)
 *
 * 2012.10.19 fj
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace szpgy2_4_1_Leibnitz_pi
{
    class Leibnitz
    {
        public double szamol()
        {
            double sor = 1;       // sorozat els� eleme

            double i = 3;         // sorozat m�sodik elem�nek oszt�ja
            double elojel = -1;   // el�jelk�pz�s ind�t�sa

            while (Math.Abs(4*sor-4*(sor+elojel/i))>=0.000001)
            {
                sor += elojel/i;
                elojel = -1 * elojel;
                i+=2;
            }
            return Math.Abs(4*sor);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {

            Leibnitz pi = new Leibnitz();

            Console.WriteLine("Leibnitz-f�le sorral:{0:F6}", pi.szamol());
            Console.WriteLine("Math.PI f�ggv�nnyel :{0:F6}", Math.PI);

        }
    }
}