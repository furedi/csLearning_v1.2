/*
Hat�rozzuk meg k�t billenty�zetr�l
beolvasott sz�m legnagyobb k�z�s
oszt�j�t az euklideszi algoritmus
seg�ts�g�vel.
*/
using System;

namespace fuggvenyek
{
  class Program
  {
     // --------------------- csere f�ggv�ny
     static void csere(ref int szam1, ref int szam2)
     {
        if (szam1<szam2)
        {
           int x=szam1;
           szam1=szam2;
           szam2=x;
        }
     }
     // --------------------- lnko f�ggv�ny
     static int lnko(int a,int b)
     {
        csere( ref a, ref b);
        int m ;
        do
        {
           m=a % b;
           a=b;
           b=m;
         } while (m!=0);

        return a;
     }

     //====================== FOPROGRAM     
     static void Main(string[] args)
     {
        Console.WriteLine("Legnagyobb k�z�s oszt� keres�se\r\n");
        Console.Write("n=");
        int n= Convert.ToInt32(Console.ReadLine());

        Console.Write("m=");
        int m= Convert.ToInt32(Console.ReadLine());
        
        int kozos_oszto=lnko(n,m);        
 
        Console.WriteLine("LNKO = {0}",kozos_oszto);

        Console.Write("\r\nK�rem nyomja le az ENTER-t");
        Console.ReadLine();
     }
  }
}
