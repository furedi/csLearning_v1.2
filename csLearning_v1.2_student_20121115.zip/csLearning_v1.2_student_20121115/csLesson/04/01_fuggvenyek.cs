/*
Sz�m�tsuk ki n faktori�lis �rt�k�t
f�ggv�ny seg�ts�g�vel.
*/
using System;

namespace fuggvenyek
{
  class Program
  {
     // faktori�lis kisz�m�t� f�ggv�ny
     // iter�ci�val
     static int faktor(int szam)
     {
        int f=1;
        for (int i=1; i<=szam; i++)
           f *=i;
        return f;
     }

     //====================== FOPROGRAM     
     static void Main(string[] args)
     {
        Console.Write("n=");
        int n= Convert.ToInt32(Console.ReadLine());
        // --- faktor() f�ggv�ny h�v�sa
        Console.WriteLine(
           "{0} faktori�lis = {1}",n,faktor(n));

        Console.Write("\r\nK�rem nyomja le az ENTER-t");
        Console.ReadLine();
     }
  }
}
