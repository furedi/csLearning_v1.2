// Irassuk ki az 1 �s 100 k�z�tt
// a legnagyobb h�rommal �s h�ttel
// oszthat� sz�mot!

using System;

namespace kiugrik
{
    class Program
    {
        static void Main(string[] args)
        {
           for (int i = 100; i > 0; i--) 
           {
              if (i % 3 == 0 && i % 7 == 0)
              {
                 Console.WriteLine(i);
                 break;
              }
           }
           
        }
    }
}
