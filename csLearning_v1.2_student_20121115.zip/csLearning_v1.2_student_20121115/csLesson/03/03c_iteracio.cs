/*
Irassa ki a 10 es szorz�t�bl�t
*/

using System;

namespace feladatsor_7
{
  class Program
  {
    static void Main(string[] args)
    {
       for (int j=1;j<=10;j++)
       {     
           for (int i=1;i<=10;i++)
               Console.Write("{0,4}",j*i);
           Console.WriteLine();
       }
    }

  } // class v�ge
} // namespace v�ge
