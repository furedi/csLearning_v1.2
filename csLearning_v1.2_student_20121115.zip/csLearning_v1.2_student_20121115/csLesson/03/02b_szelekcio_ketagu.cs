/*
Olvasson be egy eg�sz sz�mot, 
majd dontse el, hogy p�ros vagy
 p�ratlan sz�m-e?
*/
using System;

namespace ConsoleApplication1
{
  class Program
  {
    static void Main(string[] args)
    {
      int x;
      Console.Write("x=");
      x = Convert.ToInt32(Console.ReadLine());

      if (x % 2 ==0)   
         Console.WriteLine("P�ros");
      else
         Console.WriteLine("P�ratlan");

      Console.WriteLine("\r\nKerem nyomja le ENTER-t");
      Console.ReadLine();
    }
  }
}
