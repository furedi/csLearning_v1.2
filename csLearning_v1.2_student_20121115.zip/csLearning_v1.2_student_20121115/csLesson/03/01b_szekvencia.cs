/*
Sz�moljuk ki 16 n�gyzetgy�k�t,
majd irassuk ki a kapott �rt�ket
*/
using System;

namespace ConsoleApplication1
{
   class Program
   {
      static void Main(string[] args)
      {
         Random r = new Random();
         int szam = r.Next(1,101);
         Console.WriteLine("V�letlensz�m gener�l�s: {0}", szam);
      }
   }
}
