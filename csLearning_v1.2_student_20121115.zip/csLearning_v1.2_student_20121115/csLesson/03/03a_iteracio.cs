/*
Irassa ki a 256-nal kisebb h�rommal
oszthat� sz�mokat
*/

using System;

namespace feladatsor_7
{
  class Program
  {
    static void Main(string[] args)
    {
       for (int i=1; i<256; i++)
       {
          if (i % 3 ==0) Console.Write("{0}, ",i);
       }
    }

  } // class v�ge
} // namespace v�ge
