/*
Olvassa be eg h�nap sorsz�mt,
majd irassa ki az �vszakot!
*/

using System;

namespace ConsoleApplication1
{
  class Program
  {
    static void Main(string[] args)
    {
      int h�nap;
      Console.Write("h�nap=");
      h�nap = Convert.ToInt32(Console.ReadLine());

      if (h�nap==12 || h�nap<3)
         Console.WriteLine("T�l");
      else if (h�nap<7)
         Console.WriteLine("Tavasz");
      else if (h�nap<10)
         Console.WriteLine("Ny�r");
      else if (h�nap<12)
         Console.WriteLine("�sz");
      else
         Console.WriteLine("Hib�s adat");

      Console.WriteLine("\r\nKerem nyomja le ENTER-t");
      Console.ReadLine();
    }
  }
}
