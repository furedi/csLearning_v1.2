using System;
using System.IO;

namespace kiv�tel
{
    class Program
    {
        static void Main(string[] args)
        {
          System.IO.FileStream file = null;
          try
          {
            file = new System.IO.FileStream("C:\\myFile.txt",
            System.IO.FileMode.Open);
          }
          catch(System.IO.FileNotFoundException fnf)
          {
            Console.WriteLine("Nincs "+fnf.FileName+" f�jl!");
          }
          finally
          {
            Console.WriteLine("Finally");
            if (file != null) file.Close();
          }
        }
    }
}
