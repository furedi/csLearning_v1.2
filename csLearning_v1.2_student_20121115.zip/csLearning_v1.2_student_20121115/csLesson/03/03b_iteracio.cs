/*
Irassa ki a 256-nal kisebb n�gyzet sz�mokat,
amelyek oszthat�k h�rommal.
*/

using System;

namespace feladatsor_7
{
  class Program
  {
    static void Main(string[] args)
    {
   
       int i=1;

       while (i*i<256)
       {
          if (i*i % 3 == 0) Console.Write("{0}, ",i*i);
          i++;
       }
    }

  } // class v�ge
} // namespace v�ge
