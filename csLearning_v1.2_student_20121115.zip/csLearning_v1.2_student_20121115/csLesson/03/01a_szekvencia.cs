/*
Sz�moljuk ki 16 n�gyzetgy�k�t,
majd irassuk ki a kapott �rt�ket
*/
using System;

namespace ConsoleApplication1
{
   class Program
   {
      static void Main(string[] args)
      {
         int x = 16;
         double gyok = Math.Sqrt(x);
         Console.WriteLine("{0} n�gyzetgy�ke {1}", x, gyok);
      }
   }
}
