// Irassuk ki az 1 �s 10 k�z�tti
// h�rommal oszthat� sz�mokat

using System;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
           for (int i = 1; i <= 10; i++) 
           {
              if (i % 3 != 0) continue;
              Console.WriteLine(i);
           }
        }
    }
}
