using System;

namespace nevek
{
   class Program
   {
       static void Main(string[] args)
       {
          // �rja �t a n�v �rt�k�t a forr�sk�dban
          string n�v=null;

          switch (n�v)
          {
           case "Charles":
             Console.WriteLine("Hello "+n�v);
             break;
           case null:
              Console.WriteLine(
                 "K�rem adja meg a felhaszn�l�nev�t!");
              break;
           case "":
              Console.WriteLine(
                 "A felhaszn�l�n�v legal�bb 6 karakteres");
              break;
           default:
              Console.WriteLine("�n nem Charles.");
              break;
           }
        }
    }
}
