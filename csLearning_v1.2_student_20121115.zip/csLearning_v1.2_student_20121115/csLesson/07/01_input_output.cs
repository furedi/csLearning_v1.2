using System;
namespace myNameSpace
{
   class myClass
   {
      [STAThread]
      static void Main(string[] args)
      {
         // --- Konzol sz�nek kezel�se 
         Console.BackgroundColor = ConsoleColor.White;
         Console.ForegroundColor = ConsoleColor.Blue;
         Console.Clear();
         int a=0,b=0;

         Console.Write("a erteke : ");
         a=Convert.ToInt32(Console.ReadLine());

         Console.Write("b erteke : ");
         b=Convert.ToInt32(Console.ReadLine());

         Console.WriteLine("\n a={0}\n b={1}\n a+b={2}",a,b,a+b);

         Console.Write("\r\nK�rem nyomja le az ENTER-t!");
         Console.ReadLine();
      }
   }
}
