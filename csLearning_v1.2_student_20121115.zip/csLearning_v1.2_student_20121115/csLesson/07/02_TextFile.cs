/*
Sz�veges file �r�sa a %TMP% k�rnyezeti
v�ltoz�ban megadott mapp�ba,
majd a teszt.txt tartalm�nak kiirat�sa
*/

using System;
using System.IO;

class Test
  {
  public static void Main()
  {
    //--- Ideiglenes �llom�nyok k�nyvt�ra
    string tmp = Environment.GetEnvironmentVariable("TMP");
    Console.WriteLine("A sz�veges �llom�ny mapp�ja:\r\n"+tmp+"\r\n");

    //----------------------- f�jl�r�s
    StreamWriter sw = new StreamWriter(tmp+"\\Teszt.txt"); //ki�r�s.
    sw.Write("Szia ");
    sw.WriteLine("EZ A SOR FOLYTAT�SA.");
    sw.WriteLine("�jabb sor.");
    sw.Close();

    //----------------------- f�jlolvas�s.
    StreamReader sr = new StreamReader(tmp+"\\Teszt.txt");
    string sor;
    // olvas�s soronk�nt, am�g van adat
    while ((sor = sr.ReadLine()) != null)
    {
       Console.WriteLine(sor);
    }
    sr.Close();

    //----------------------- f�jl t�rl�se a munkak�nyvt�rb�l
    try
      {
        if (File.Exists(tmp + "\\Teszt.txt"))
        {
           File.Delete(tmp + "\\Teszt.txt");
           Console.WriteLine("\r\nSz�veges �llom�ny t�rl�se:\r\n"+tmp+"\\Teszt.txt");
        }
      }
      catch (IOException ex)
      {
         Console.WriteLine(ex.Message);
      }

    Console.WriteLine("\r\nAktu�lis k�nyvt�r el�r�si �tja:\r\n"+Directory.GetCurrentDirectory());
  }
}
