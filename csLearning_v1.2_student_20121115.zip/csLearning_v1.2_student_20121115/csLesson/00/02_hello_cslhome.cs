using System;

namespace HelloVilag
{
   class Program
   {
      static void Main(string[] args)
      {
          Console.WriteLine("Hello vil�g");

          Console.WriteLine("\r\nAz aktu�lis munkak�nyvt�r:\r\n");
          Console.WriteLine(Environment.GetEnvironmentVariable("cslhome"));
      }
   }
}
