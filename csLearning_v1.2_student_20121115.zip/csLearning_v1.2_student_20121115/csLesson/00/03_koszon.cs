/*
�rjon programot, amely beolvassa a felhaszn�l� nev�t,
majd �dv�zli �t. A program �n�l� ablakban fog futni!
*/

using System;

namespace ConsoleApplication1
{
   class Program
   {
      static void Main(string[] args)
      {
         // --- Konzol sz�nek kezel�se 
         Console.BackgroundColor = ConsoleColor.White;
         Console.ForegroundColor = ConsoleColor.Blue;
         Console.Clear();

         Console.WriteLine("Hello vil�g\r\n");

         Console.Write("K�rem adja meg a nev�t:");

          //-----------------  Adatbevitel
          string nev = Console.ReadLine();

          Console.WriteLine("Hello {0}!",nev);

          //--------------- Ablak bez�r�sa ENTER lenyom�sa ut�n
          Console.Write("\r\nK�rem nyomja le az ENTER-t!");
          Console.ReadLine();
          //--------------- Konzol alkalmaz�s v�g�n c�lszer� haszn�lni
      }
   }
}
