using System;

namespace HelloVilag
{
   class Program
   {
      static void Main(string[] args)
      {
          Console.WriteLine("Hello vil�g");
      }
   }
}
