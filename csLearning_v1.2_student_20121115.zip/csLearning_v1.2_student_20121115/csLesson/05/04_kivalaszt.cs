/*
Adjuk meg egy eg�sz sz�mokb�l �ll� t�mb
els� 9-cel oszthat� elem�t, ha tudjuk,
hogy ilyen elemet biztosan tartalmaz a sorozat!
*/

using System;
namespace n�vterem  //-------- nevter kezdete
{
  class progtetelek //-------- osztaly kezdete
  {
     //---------------------- kivalaszt
     static int kivalaszt(ref int[] tomb, int a)
     {
        int i=0;

        while (tomb[i] % a > 0)
           i++;
 
        return i;
     }
     //====================== FOPROGRAM
     static void Main()
      {
         int[] szamok = {15, 345, 36, 77, 152, 353};
         int oszto=9;
         Console.WriteLine("Az elso {0}-el oszthat� szam: {1}", oszto,
                            szamok[kivalaszt(ref szamok, oszto)]);
      }

   } // --------------------- osztaly v�ge
}    // --------------------- nevter v�ge
