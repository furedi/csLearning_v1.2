/*
Egy oszt�ly tanul�inak egy�ni �tlageredm�nyeinek
ismeret�ben adjuk meg az oszt�ly �tlag�t!
*/

using System;
namespace n�vterem  //-------- nevter kezdete
{
  class progtetelek //-------- osztaly kezdete
  {
     //---------------------- atlag
     static double atlag(ref double[] tomb)
     {
        double osszeg=0;
        for (int i=0; i<tomb.Length; i++)
          osszeg += tomb[i];
        return osszeg/tomb.Length;
     }
     //====================== FOPROGRAM
     static void Main()
      {
         double[] tanulok = {4.25, 3.60, 3.00, 2.39, 4.2,
                             3.50, 2.80, 4.30, 3.9, 4.10};
         Console.WriteLine("A {0} tanulo atlaga {1,4:0.00}",tanulok.Length,atlag(ref tanulok));
      }

   } // --------------------- osztaly v�ge
}    // --------------------- nevter v�ge
