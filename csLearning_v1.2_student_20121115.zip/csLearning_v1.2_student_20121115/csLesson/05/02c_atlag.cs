/*
Hat�rozzuk meg egy �t elem� adatsorozat pozit�v 
elemeinek �tlag�t!
*/

using System;
namespace n�vterem //-------- n�vt�r kezdete
{
   class megszamol //-------- oszt�ly kezdete
   {
      static void Main()
      {
         int[] t�mb = {12,45,67,-56, 39};
         int i=0,db=0,�sszeg = 0;

         while (i<t�mb.Length)
         {
            if (t�mb[i]>0) 
              {
                 db ++;
                 �sszeg += t�mb[i];
              }
            i++;
         }
         Console.WriteLine("A pozit�v sz�mok sz�ma  : {0,5}",db);
         Console.WriteLine("A pozit�v sz�mok osszege: {0,5}",�sszeg);
         Console.WriteLine("A pozit�v sz�mok �tlaga : {0,8:0.00}",(double)�sszeg/db);
      }

   } // --------------------- oszt�ly v�ge
}    // --------------------- n�vter v�ge
