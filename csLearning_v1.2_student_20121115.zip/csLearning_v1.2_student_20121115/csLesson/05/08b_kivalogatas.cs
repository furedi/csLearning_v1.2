/*
Adott egy neveket �s �letkorokat tartalmaz� t�mb.
V�logassuk ki a 18 �vesn�l fiatalabbakat.
*/

using System;
namespace n�vterem  //-------- nevter kezdete
{
  //------------------------- Adatstruktura defini�l�sa
  struct adat
  {
     public adat(string nev, byte eletkor)
       { this.nev=nev;
         this.eletkor=eletkor;}

     public string nev;
     public byte eletkor;
  }

  class progtetelek //-------- osztaly kezdete
  {
     //---------------------- Kiv�logat�s
     static void kivalogat(ref adat[] forras, int ertek, ref adat[] cel)
     {
        int i=0, j=0;
        while (i<forras.Length)
        {
           if (forras[i].eletkor<ertek) 
             {
                cel[j]=forras[i];
                j++;
             }
           i++;
        }
        Array.Resize(ref cel, j);
     }

     //====================== FOPROGRAM
     static void Main()
      {
         adat[] diakok = 
                {
                  new adat("Albert", 16) ,
                  new adat("Cecil", 18),
                  new adat("Elem�r",15),
                  new adat("Gergely",21),
                  new adat("K�lm�n",17),
                  new adat("Zolt�n",16),
                };
         adat[] diakok18 = new adat[diakok.Length];
         byte kor = 18;

         Console.WriteLine("A diakok tomb {0} bemen� adata:",diakok.Length);
         foreach(adat diak in diakok)
            Console.WriteLine("{0,-10} {1,2}",diak.nev,diak.eletkor);

         kivalogat(ref diakok, kor, ref diakok18);

         Console.WriteLine("\r\n{0} �v alattiak szama {1}:",kor,diakok18.Length);

         foreach(adat diak in diakok18)
            Console.WriteLine("{0,-10} {1,2}",diak.nev,diak.eletkor);
      }
   } // --------------------- osztaly v�ge
}    // --------------------- nevter v�ge
