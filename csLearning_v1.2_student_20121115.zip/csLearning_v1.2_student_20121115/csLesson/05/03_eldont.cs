/*
D�nts�k el egy tanul� �v v�gi jegyei
alapj�n, hogy kit�n� tanul�-e!
*/

using System;
namespace n�vterem  //-------- nevter kezdete
{
  class progtetelek //-------- osztaly kezdete
  {
     //---------------------- eldont
     static bool kituno(ref byte[] tomb)
     {
        byte i=0;

        while (i<tomb.Length && tomb[i]==5)
           i++;
 
        return i==tomb.Length;
     }
     //====================== FOPROGRAM
     static void Main()
      {
         byte[] jegyek = {4, 5, 5, 5, 5, 5};
         Console.WriteLine("A kit�n�-e a tanulo: {0}",kituno(ref jegyek));
      }

   } // --------------------- osztaly v�ge
}    // --------------------- nevter v�ge
