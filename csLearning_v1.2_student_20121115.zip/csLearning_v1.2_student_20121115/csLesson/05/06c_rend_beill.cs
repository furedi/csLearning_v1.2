/*
�rj programot, mely egy rendezetlen sz�msort
a beilleszt�ses rendez�s m�dszer�vel 
n�vekv� sorrendbe rendez!
*/

using System;
namespace n�vterem  //-------- nevter kezdete
{
  class progtetelek //-------- osztaly kezdete
  {
     //---------------------- Beilleszt�ses rendez�s
     static void rend_beill(ref int[] tomb)
     {
        int j,x;

        for (int i=1; i< tomb.Length;i++)
        {
           x=tomb[i];
           j=i-1;
           while (j>-1 && x<tomb[j])
           {
              tomb[j+1]=tomb[j];
              j--;
           }
           tomb[j+1]=x;
        }
     }

     static void kiir(ref int[] tomb)
     {
        for  (int i=0;i<tomb.Length;i++)
           Console.Write("{0}, ",tomb[i]);

        Console.WriteLine("\n");
     }

     //====================== FOPROGRAM
     static void Main()
      {
         int[] szamok = {20, 15, 345, 36, 777, 152, 353, 34, 534};

         kiir(ref szamok);

         rend_beill(ref szamok);

         kiir(ref szamok);
      }

   } // --------------------- osztaly v�ge
}    // --------------------- nevter v�ge
