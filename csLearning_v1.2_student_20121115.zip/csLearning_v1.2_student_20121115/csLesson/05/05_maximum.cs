/*
Keress�k egy t�mb elemeinek maximum�t:
H�nyadik �s mi az �rt�ke?
*/

using System;
namespace n�vterem  //-------- nevter kezdete
{
  class progtetelek //-------- osztaly kezdete
  {
     //---------------------- maximum
     static int max(ref int[] tomb)
     {
        int maxidx = 0;

        for (int i=1; i<tomb.Length; i++)
           if (tomb[i]>tomb[maxidx]) maxidx=i;

        return maxidx;
     }
     //====================== FOPROGRAM
     static void Main()
      {
         int[] szamok = {15, 345, 36, 777, 152, 353};

         int legnagyobb=max(ref szamok);

         Console.WriteLine("{0}. elem a legnagyobb, �rt�ke: {1}",
               legnagyobb, szamok[legnagyobb]);
      }

   } // --------------------- osztaly v�ge
}    // --------------------- nevter v�ge
