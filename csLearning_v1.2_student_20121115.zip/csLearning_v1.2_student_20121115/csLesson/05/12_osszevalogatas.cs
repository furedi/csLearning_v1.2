/*
�ll�ts el� k�t n�vekv� sz�msorb�l egy 
harmadik n�vekv� sort, mely az 
�sszes elemet tartalmazza!
*/

using System;
namespace n�vterem  //-------- nevter kezdete
{
  class progtetelek //-------- osztaly kezdete
  {
     //---------------------- �sszev�logat�s
     static void osszevalogat(ref int[] a, ref int[] b, ref int[] c)
     {
        //------------------- �tk�z�k elhelyez�se
        Array.Resize(ref a, a.Length+1);
        a[a.Length-1]=int.MaxValue;

        Array.Resize(ref b, b.Length+1);
        b[b.Length-1]=int.MaxValue;

        int a_idx=0, b_idx=0, c_idx=-1;
        
        while (a_idx < a.Length-1 || b_idx< b.Length-1)
        {
           c_idx++;
           if (a[a_idx]<b[b_idx])
              {
                 c[c_idx]=a[a_idx];
                 a_idx++;
              }
           else
              {
                 c[c_idx]=b[b_idx];
                 b_idx++;
              }
        }
        // ------------------ �tk�z�k elt�vol�t�sa
        Array.Resize(ref a, a.Length-1);
        Array.Resize(ref b, b.Length-1);
     }

     //---------------------- Kiirat�s
     static void kiir(ref int[] tomb)
     {
        foreach (int elem in tomb)
           Console.Write("{0}, ",elem);

        Console.WriteLine("\n");
     }
     //====================== FOPROGRAM
     static void Main()
      {
         int[] a_szamsor = {20, 35, 45, 76, 87, 152, 353, 534};
         int[] b_szamsor = {22, 35, 55, 76, 87, 313, 534};

         int[] c_eredmeny = new int[a_szamsor.Length + b_szamsor.Length];

         Console.WriteLine("Az a_szamsor tomb {0} bemen� adata:",a_szamsor.Length);
         kiir(ref a_szamsor);

         Console.WriteLine("\r\nAz b_szamsor tomb {0} bemen� adata:",b_szamsor.Length);
         kiir(ref b_szamsor);

         osszevalogat(ref a_szamsor, ref b_szamsor, ref c_eredmeny);

         Console.WriteLine("\r\n�sszev�logatott sorozat elemienek sz�ma {0}:",c_eredmeny.Length);
         kiir(ref c_eredmeny);
      }
   } // --------------------- osztaly v�ge
}    // --------------------- nevter v�ge
