/*
H�ny olyan sz�m van az adott val�s sorban,
melyek kisebbek egy megadottn�l?
*/

using System;
namespace n�vterem  //-------- nevter kezdete
{
  class progtetelek //-------- osztaly kezdete
  {
     //---------------------- megszamol
     static int megszamol(ref double[] tomb, double kuszob)
     {
        int db=0;
        foreach(double d in tomb)
          if (d < kuszob) db++;
        return db;
     }
     //====================== FOPROGRAM
     static void Main()
      {
         double[] szamok = {12.25,45,67,-56, 39.2};
         double szam = 30;   // k�sz�bsz�m meghat�roz�sa
         Console.WriteLine("{0} db {1}-n�l kisebb sz�m van az adatsorban",
                            megszamol(ref szamok,szam),szam);
      }

   } // --------------------- osztaly v�ge
}    // --------------------- nevter v�ge
