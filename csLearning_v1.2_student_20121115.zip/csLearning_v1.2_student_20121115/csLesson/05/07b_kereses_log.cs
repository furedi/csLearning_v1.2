/*
Egy rendezett n�vekv� eg�sz �rt�keket tartalmaz�
sz�msorban keress meg egy adott eg�sz sz�mot,
majd �rd ki, hogy van-e �s ha van, h�nyadik!
*/

using System;
namespace n�vterem  //-------- nevter kezdete
{
  class progtetelek //-------- osztaly kezdete
  {
     //---------------------- Logaritmikus keres�s
     static bool keres_lin(ref int[] tomb, int ertek, ref int kozepso)
     {
        int elso=0,
            utolso=tomb.Length-1;

        kozepso=0;
        bool van=false;
        while (elso<=utolso && !van)
        {
           kozepso=(elso+utolso)/2;
           if (ertek == tomb[kozepso]) van=true;
           else if (ertek < tomb[kozepso]) utolso=kozepso-1;
           else elso=kozepso+1;
        }
        return van;
     }

     //====================== FOPROGRAM
     static void Main()
      {
         int[] szamok = {20, 35, 45, 76, 87, 152, 353, 534};
         int szam=87;
         int ssz=0;

         if (keres_lin(ref szamok, szam, ref ssz))
            Console.WriteLine("{0} sz�m sorsz�ma {1}", szam, ssz);
         else Console.WriteLine("{0} sz�m nincs a sorozatban", szam);
      }
   } // --------------------- osztaly v�ge
}    // --------------------- nevter v�ge
