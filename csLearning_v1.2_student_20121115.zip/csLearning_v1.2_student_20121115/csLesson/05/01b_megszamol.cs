/*
Sz�moljuk meg egy �t elem� adatsorozat
pozit�v elemeit!
*/

using System;
namespace n�vterem //-------- n�vt�r kezdete
{
   class megszamol //-------- oszt�ly kezdete
   {
      static void Main()
      {
         int[] t�mb = {12,45,67,-56, 39};
         int i=0,db = 0;

         while (i<t�mb.Length)
         {
            if (t�mb[i]>0) db++;
            i++;
         }

         Console.WriteLine("{0} db pozit�v sz�m van az adatsorban",db);
      }

   } // --------------------- oszt�ly v�ge
}    // --------------------- n�vter v�ge
