/*
Add meg egy val�s sz�msorozat els� -5-n�l kisebb
elem�nek sorsz�m�t, ha van ilyen!
*/

using System;
namespace n�vterem  //-------- nevter kezdete
{
  class progtetelek //-------- osztaly kezdete
  {
     //---------------------- Line�ris keres�s
     static bool keres_lin(ref double[] tomb, double ertek, ref int i)
     {
        i=0;
        while (i<tomb.Length && tomb[i]>=ertek)
           i++;
        return i<tomb.Length;
     }

     //====================== FOPROGRAM
     static void Main()
      {
         double[] szamok = {20, 15, -345, 36, 777, 152, 353, 34, 534};
         double szam=-5;
         int ssz=0;

         if (keres_lin(ref szamok, szam, ref ssz))
            Console.WriteLine("{0} sz�mn�l kisebb elem sorsz�ma {1}", szam, ssz);
         else Console.WriteLine("{0} sz�mn�l kisebb elem nincs a sorozatban", szam);
      }
   } // --------------------- osztaly v�ge
}    // --------------------- nevter v�ge
