/*
�rj programot, mely egy rendezetlen sz�msort
a bubor�kos rendez�s m�dszer�vel 
n�vekv� sorrendbe rendez!
*/

using System;
namespace n�vterem  //-------- nevter kezdete
{
  class progtetelek //-------- osztaly kezdete
  {
     //---------------------- Bubor�kos rendez�s
     static void rend_bub(ref int[] tomb)
     {
        int i=tomb.Length-1;        
        int x;

        bool rendezett=false;
        while (i>0 && !rendezett)
        {
           rendezett=true;
           for (int j=0;j<i;j++)
              if (tomb[j]>tomb[j+1])
              {
                 x=tomb[j];
                 tomb[j]=tomb[j+1];
                 tomb[j+1]=x;
                 rendezett=false;
              }
           i--;
        }
     }

     static void kiir(ref int[] tomb)
     {
        for  (int i=0;i<tomb.Length;i++)
           Console.Write("{0}, ",tomb[i]);

        Console.WriteLine("\n");
     }

     //====================== FOPROGRAM
     static void Main()
      {
         int[] szamok = {20, 15, 345, 36, 777, 152, 353, 34, 534};

         kiir(ref szamok);

         rend_bub(ref szamok);

         kiir(ref szamok);
      }

   } // --------------------- osztaly v�ge
}    // --------------------- nevter v�ge
