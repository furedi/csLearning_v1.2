/*
�rj programot, mely k�t beolvasott sz�msorozatot
egy harmadik t�mbben helyez el �gy, hogy ha valamelyik
sz�m mindkett�ben szerepel, akkor az egyes�t�sben
csak egyszer szerepeljen!
*/

using System;
namespace n�vterem  //-------- nevter kezdete
{
  class progtetelek //-------- osztaly kezdete
  {
     //---------------------- Uniok�pz�s
     static void unio(ref int[] a, ref int[] b, ref int[] c)
     {
        int j=0,k=a.Length;

        Array.Copy(a,c,a.Length);
        
        for (int i=0; i<b.Length; i++)
        {
           j=0;
           while (j<k && b[i]!=c[j])
              j++;

           if (j>=k)
              {
                c[k]=b[i];
                k++;
              }
        }
        Array.Resize(ref c, k);
     }
     //---------------------- Kiirat�s
     static void kiir(ref int[] tomb)
     {
        foreach (int elem in tomb)
           Console.Write("{0}, ",elem);

        Console.WriteLine("\n");
     }
     //====================== FOPROGRAM
     static void Main()
      {
         int[] a_szamsor = {20, 35, 45, 76, 87, 152, 353, 534};
         int[] b_szamsor = {22, 35, 55, 76, 87, 313, 534};

         int[] c_unio = new int[a_szamsor.Length + b_szamsor.Length];

         Console.WriteLine("Az a_szamsor tomb {0} bemen� adata:",a_szamsor.Length);
         kiir(ref a_szamsor);

         Console.WriteLine("\r\nAz b_szamsor tomb {0} bemen� adata:",b_szamsor.Length);
         kiir(ref b_szamsor);

         unio(ref a_szamsor, ref b_szamsor, ref c_unio);

         Console.WriteLine("\r\nEgyes�tett sorozat elemienek sz�ma {0}:",c_unio.Length);
         kiir(ref c_unio);
      }
   } // --------------------- osztaly v�ge
}    // --------------------- nevter v�ge
