/*
�rj programot, mely egy rendezetlen sz�msort
a minimum-kiv�laszt�s m�dszer�vel rendez
n�vekv� sorrendbe!
*/

using System;
namespace n�vterem  //-------- nevter kezdete
{
  class progtetelek //-------- osztaly kezdete
  {
     //---------------------- minimum v�laszt�sos rendez�s
     static void rend_min(ref int[] tomb)
     {
        int minidx, x;       
 
        for (int i=0; i<tomb.Length-1;i++)
        {
           minidx=i;

           for (int j=i+1;j<tomb.Length;j++)
              if (tomb[j]<tomb[minidx]) minidx=j;

           //---------------- csere
           if (i!=minidx)
           {
              x=tomb[i];
              tomb[i]=tomb[minidx];
              tomb[minidx]=x;
           }
        }
     }
     static void kiir(ref int[] tomb)
     {
        for  (int i=0;i<tomb.Length;i++)
           Console.Write("{0}, ",tomb[i]);

        Console.WriteLine("\n");
     }

     //====================== FOPROGRAM
     static void Main()
      {
         int[] szamok = {15, 345, 36, 777, 152, 353, 34};

         kiir(ref szamok);

         rend_min(ref szamok);

         kiir(ref szamok);
      }

   } // --------------------- osztaly v�ge
}    // --------------------- nevter v�ge
