/*
Adott egy negat�v �s pozit�v eg�sz sz�mokat tartalmaz� t�mb.
V�logassuk ki a pozit�v sz�mokat egy tombbe.
*/

using System;
namespace n�vterem  //-------- nevter kezdete
{
  class progtetelek //-------- osztaly kezdete
  {
     //---------------------- Kiv�logat�s
     static void kivalogat(ref int[] forras, int ertek, ref int[] cel)
     {
        int i=0, j=0;
        while (i<forras.Length)
        {
           if (forras[i]>ertek) 
             {
                cel[j]=forras[i];
                j++;
             }
           i++;
        }
        Array.Resize(ref cel, j);
     }
     //---------------------- Kiirat�s
     static void kiir(ref int[] tomb)
     {
        foreach (int elem in tomb)
           Console.Write("{0}, ",elem);

        Console.WriteLine("\n");
     }
     //====================== FOPROGRAM
     static void Main()
      {
         int[] szamok = {20, 35, -45, 76, -87, -152, 353, 534};
         int[] pozitiv = new int[szamok.Length];
         int szam = 0;

         Console.WriteLine("A szamok tomb {0} bemen� adata:",szamok.Length);
         kiir(ref szamok);

         kivalogat(ref szamok, szam, ref pozitiv);

         Console.WriteLine("\r\n{0} �rt�k alattiak szama {1}:",szam,pozitiv.Length);
         kiir(ref pozitiv);
      }
   } // --------------------- osztaly v�ge
}    // --------------------- nevter v�ge
