/*
Egy t�mb elemeit v�logasd sz�t
parit�suk alapj�n k�t �j t�mbbe!
*/

using System;
namespace n�vterem  //-------- nevter kezdete
{
  class progtetelek //-------- osztaly kezdete
  {
     //---------------------- Sz�tv�logat�s
     static void szetvalogat(ref int[] forras, ref int[] prs, ref int[] prt)
     {
        int i=0, j=0, k=0;
        while (i<forras.Length)
        {
           if (forras[i] % 2 == 0 ) 
            {
               prs[j]=forras[i];
               j++;
            }
            else
            {
               prt[k]=forras[i];
               k++;
            }
            i++;
        }
        Array.Resize(ref prs, j);
        Array.Resize(ref prt, k);
     }
     //---------------------- Kiirat�s
     static void kiir(ref int[] tomb)
     {
        foreach (int elem in tomb)
           Console.Write("{0}, ",elem);

        Console.WriteLine("\n");
     }
     //====================== FOPROGRAM
     static void Main()
      {
         int[] szamok = {20, 35, 45, 76, 87, 152, 353, 534};
         int[] paros = new int[szamok.Length];
         int[] paratlan = new int[szamok.Length];
         int szam = 0;

         Console.WriteLine("A szamok tomb {0} bemen� adata:",szamok.Length);
         kiir(ref szamok);

         szetvalogat(ref szamok, ref paros, ref paratlan);

         Console.WriteLine("\r\nP�ros sz�mok sz�ma {0}:",paros.Length);
         kiir(ref paros);

         Console.WriteLine("\r\nP�ratlan sz�mok sz�ma {0}:",paros.Length);
         kiir(ref paratlan);

      }
   } // --------------------- osztaly v�ge
}    // --------------------- nevter v�ge
