/*
�rj programot, mely k�t adott sz�msorozatot vizsg�lva
megkeresi a mindkett�ben megtal�lhat� sz�mokat!
*/

using System;
namespace n�vterem  //-------- nevter kezdete
{
  class progtetelek //-------- osztaly kezdete
  {
     //---------------------- Metszetk�pz�s
     static void metszet(ref int[] a, ref int[] b, ref int[] c)
     {
        int i=0, j=0, k=0;

        for (i=0; i<a.Length; i++)
        {
           j=0;
           while (j<b.Length && b[j]!=a[i])
              j++;

           if (j<b.Length)
              {
                c[k]=a[i];
                k++;
              }
        }
        Array.Resize(ref c, k);
     }
     //---------------------- Kiirat�s
     static void kiir(ref int[] tomb)
     {
        foreach (int elem in tomb)
           Console.Write("{0}, ",elem);

        Console.WriteLine("\n");
     }
     //====================== FOPROGRAM
     static void Main()
      {
         int[] a_szamsor = {20, 35, 45, 76, 87, 152, 353, 534};
         int[] b_szamsor = {22, 35, 55, 76, 87, 313, 534};

         int[] kozos = new int[a_szamsor.Length < b_szamsor.Length ? a_szamsor.Length : b_szamsor.Length];

         Console.WriteLine("Az a_szamsor tomb {0} bemen� adata:",a_szamsor.Length);
         kiir(ref a_szamsor);

         Console.WriteLine("\r\nAz b_szamsor tomb {0} bemen� adata:",b_szamsor.Length);
         kiir(ref b_szamsor);

         metszet(ref a_szamsor, ref b_szamsor, ref kozos);

         Console.WriteLine("\r\nK�z�s sz�mok sz�ma {0}:",kozos.Length);
         kiir(ref kozos);
      }
   } // --------------------- osztaly v�ge
}    // --------------------- nevter v�ge
