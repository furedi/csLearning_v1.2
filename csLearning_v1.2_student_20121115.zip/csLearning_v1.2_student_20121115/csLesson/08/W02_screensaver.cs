/*
 * ScreenSaver program
 * 2012.02.19 fj
 * 
 * Be�ll�t�s k�perny�v�d�nek:
 * 1) bin/Debug k�nyvt�rb�l a ScreenSaver.exe m�sol�sa egy saj�t k�nyvt�rba
 * 2) A ScreenSaver.exe �tnevez�se ScreenSaver.scr n�vre.
 * 3) Jobb click a ScreenSaver.scr file-ra, majd telep�t�s.
 *    �gy elindul a k�perny�v�d� be�ll�t� ablaka.
 * 
 * Hibajelens�g Windows 7-n�l: ha a Windows\System32 k�nyvt�rba ker�l a ScreenSaver.scr file:
 * Unable to find a version of the runtime to run this application
 * http://www.dotnetthoughts.net/2010/12/22/net-framework-initialization-error-%E2%80%93-unable-to-find-a-version-of-the-runtime-to-run-this-application/
 * http://msdn.microsoft.com/en-us/library/w4atty68.aspx
 * Megold�s Windows 7 OS est�n a Windows k�nyvt�rba kell m�solni a ScreenSaver.scr file-t,
 * majd jobb click �s telep�t�s.
 * 
 * Felhaszn�lt k�p forr�sa:
 * http://harmonia.blogolj.net/2010/06/07/a-yin-es-a-yang/
 * 
 * Tov�bbi �tletek:
 * http://www.geekpedia.com/KB123_Get-current-screen-resolution-in-Csharp.html
 * http://www.harding.edu/fmccown/screensaver/screensaver.html
 * 
*/

//===================================== Program.cs
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;

namespace ScreenSaver
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}

//===================================== Form1.cs
namespace ScreenSaver
{
    public partial class Form1 : Form
    {

        Point MousePos = new Point();   // Mouse kezd�poz�ci� az elmozdul�s figyel�s�hez
        int a = 0;                      // MouseMove inicializ�l�st kezel� flag
        bool xirany = true,             // Mozg�sir�ny-v�lt�s kezel�s�hez
             yirany = true;
        Random rnd = new Random();      // PictureBox kezd�poz�ci� meghat�roz�s�hoz
        int mozog;                      // PictureBox egy elmozdul�s�nak �rt�ke

        public Form1()
        {
            InitializeComponent();

            //------------------------- PictureBox kezd�poz�ci� be�ll�t�sa
            pictureBox1.Left = rnd.Next(1, Screen.PrimaryScreen.Bounds.Width - pictureBox1.Width);
            pictureBox1.Top = rnd.Next(1, Screen.PrimaryScreen.Bounds.Height - pictureBox1.Height);

            //------------------------- Timer bekapcsol�sa
            timer1.Enabled = true;

            timer1.Interval = 32;       // PictureBox elmozdul�s gyakoris�ga
            mozog = 3;                  // PictureBox egy elmozdul�s�nak hossza
            Cursor.Hide();              // Mouse Cursor kikapcsol�sa
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            Cursor.Show();              // Mouse Cursor bekapcsol�sa
            Application.Exit();
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            Cursor.Show();              // Mouse Cursor bekapcsol�sa
            Application.Exit();
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            //------------------------- Mouse elmozdul�s nagys�g�nak figyel�se
            if (a > 0 && (Math.Abs(e.X - MousePos.X) > 2 || Math.Abs(e.Y - MousePos.Y) > 2))
            {
                Cursor.Show();          // Mouse Cursor bekapcsol�sa
                Application.Exit();
            }
            else
            {
                //--------------------- Flag az el�kl�sz�t�s v�g�nek jelz�s�re
                a = 1;
                //--------------------- Mouse indul� poz�ci� megjegyz�se
                MousePos.X = e.X;
                MousePos.Y = e.Y;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //------------------------- PictureBox ir�nyv�lt�s kezel�se
            if (pictureBox1.Left + pictureBox1.Width > ClientSize.Width) xirany = !xirany;
            else if (pictureBox1.Left < 1) xirany = !xirany;

            if (pictureBox1.Top + pictureBox1.Height > ClientSize.Height) yirany = !yirany;
            else if (pictureBox1.Top < 1) yirany = !yirany;

            //------------------------- PictureBox �j poz�ci� be�ll�t�sa
            pictureBox1.Left = (xirany) ? pictureBox1.Left + mozog : pictureBox1.Left - mozog;
            pictureBox1.Top = (yirany) ? pictureBox1.Top + mozog : pictureBox1.Top - mozog;
        }
    }
}

//===================================== Form1.Designer.cs
namespace ScreenSaver
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            //this.pictureBox1.Image = global::ScreenSaver.Properties.Resources.yin_yang;
            this.pictureBox1.Image = Image.FromFile(Environment.GetEnvironmentVariable("cslhome")+"pictures\\yin_yang.png");

            this.pictureBox1.Location = new System.Drawing.Point(45, 41);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(200, 200);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // timer1
            // 
            this.timer1.Interval = 32;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Opacity = 0.8D;
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseMove);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Timer timer1;
    }
}
//===================================== End of Application
