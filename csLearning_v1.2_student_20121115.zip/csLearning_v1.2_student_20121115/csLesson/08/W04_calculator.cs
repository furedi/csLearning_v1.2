/* 
 * K�sz�ts�nk a n�gy alapm�velet �s a hatv�nyoz�s funkci�j�val
 * rendelkez� kalkul�tort fut�sidej� komponensek haszn�lat�val.
 *
 * 2012.10.29 fj
 *
 */

using System;
using System.Globalization;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;

namespace calc
{
    //================== Form1 oszt�ly
    public class Form1 : Form
    {
        //-------------- Sz�mform�tum be�ll�t�sa
        static private string tizedesjel = CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator;
        // private NumberFormatInfo numform = CultureInfo.InvariantCulture.NumberFormat;

        //-------------- Vez�rl�k be�ll�t�si adatai
        private const int oszlop = 4, sor = 5, k=50;
        private System.Windows.Forms.TextBox kijelzo;
        private Button[,] gombok = new Button[oszlop, sor];

        private string felirat = "PC�^789/456*123-0"+tizedesjel+"=+";  // � Alt 0177

        //-------------- Sz�mol�si m�veletek v�ltoz�i
        private double a = 0;               // Calculatorban tarolt numerikus ertek
        private bool next_op = false;       // Kovetkezo operandus beolvasasa indul
        private string muvelet = "=";       // M�veleti jel t�rol�sa
        private int kiszamj = 10;           // Kijelz�n megjelen�that� sz�mjegyek

        //-------------- Form1 p�ld�nyos�t�s
        public Form1()
        {
            InitializeComponent();
        }

        //-------------- Form inicializ�l�sa
        private void InitializeComponent()
        {
            this.SuspendLayout();
            //---------- textBox tulajdons�gai
            this.kijelzo = new System.Windows.Forms.TextBox();
            this.kijelzo.Font = new System.Drawing.Font("Microsoft Sans Serif", k/2, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.kijelzo.Size = new System.Drawing.Size(oszlop*k, k);
            this.kijelzo.Location = new System.Drawing.Point(0, (k-kijelzo.Size.Height)/2);
            this.kijelzo.Name = "kijelzo";
            this.kijelzo.ReadOnly = true;
            this.kijelzo.Text = "0";
            this.kijelzo.TabIndex = 0;
            this.kijelzo.TabStop = false;
            this.kijelzo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;

            this.Controls.Add(kijelzo);

            //---------- Button t�mb felt�lt�se �s elemtulajdons�gai
            for (int i = 0; i < oszlop; i++)
            {
                for (int j = 0; j < sor; j++)
                {
                    //------- Gombok l�trehoz�sa fut�sid�ben 
                    this.gombok[i, j ] = new System.Windows.Forms.Button();
                    this.gombok[i, j ].FlatStyle = System.Windows.Forms.FlatStyle.System;
                    this.gombok[i, j ].Font = new System.Drawing.Font("Microsoft Sans Serif", k/3, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
                    this.gombok[i, j ].Text = felirat.Substring(i + j * oszlop,1);
                    this.gombok[i, j ].TabIndex = i + j * oszlop;
                    this.gombok[i, j ].Location = new System.Drawing.Point(i*k, k+j*k);
                    this.gombok[i, j ].Size = new System.Drawing.Size(k, k);

                    //------- Esem�nykezel�s
                    if (gombok[i, j ].Text=="P")
                       this.gombok[i, j ].Click += new System.EventHandler(this.button_off_Click);
                    if (gombok[i, j ].Text=="C")
                       this.gombok[i, j ].Click += new System.EventHandler(this.button_c_Click);
                    if (gombok[i, j ].Text=="�")
                       this.gombok[i, j ].Click += new System.EventHandler(this.button_sign_Click);
                    else if (("+-*/^=").IndexOf(gombok[i, j ].Text)!=-1)
                       this.gombok[i, j ].Click += new System.EventHandler(this.button_operations_Click);
                    else if (("0123456789").IndexOf(gombok[i, j ].Text)!=-1)
                       this.gombok[i, j ].Click += new System.EventHandler(this.button_numerals_Click);
                    else if ((tizedesjel).IndexOf(gombok[i, j ].Text)!=-1)
                       this.gombok[i, j ].Click += new System.EventHandler(this.button_separator_Click);

                    this.Controls.Add(gombok[i, j]);
                }
            }

            //---------- Form1 tulajdnos�gai
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightYellow;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.ClientSize = new System.Drawing.Size(oszlop * k, k + sor*k);
            this.Name = "Form1";
            this.Text = "Calculator";
            this.KeyPreview = true;
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        //-------------- Gombesem�nyek kezel�se

        private void button_off_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button_c_Click(object sender, EventArgs e)
        {
            kijelzo.Text = "0";
            a = 0;
            muvelet = "=";
            next_op=false;
        }

        private void button_sign_Click(object sender, EventArgs e)
        {
            kijelzo.Text=(-1*Double.Parse(kijelzo.Text)).ToString();
            if (next_op) a*=-1;;
        }

        private void button_operations_Click(object sender, EventArgs e)
        {
            if (!next_op) //----------- M�velet fel�l�r�sa miatt
            {
               // --------------------- K�t operandusos m�veletek
               if (muvelet == "+")        a = a + Double.Parse(kijelzo.Text);
               else if (muvelet == "-")   a = a - Double.Parse(kijelzo.Text);            
               else if (muvelet == "*")   a = a * Double.Parse(kijelzo.Text);
               else if (muvelet == "/")   a = a / Double.Parse(kijelzo.Text);
               else if (muvelet == "^")   a = Math.Pow(a,Double.Parse(kijelzo.Text));
               else a = double.Parse(kijelzo.Text);

               //---------------------- Eredm�ny kiirat�sa
               kijelzo.Text = a.ToString();

               if (kijelzo.Text.Length>kiszamj) 
               {
                   if  ((kijelzo.Text+tizedesjel).IndexOf(tizedesjel) < kiszamj-3 && kijelzo.Text.IndexOf("E")<0)
                       kijelzo.Text = (Math.Round(a,kiszamj-(kijelzo.Text+tizedesjel).IndexOf(tizedesjel))).ToString();
                   else kijelzo.Text = a.ToString("0.###E-00");
               }

            }
            muvelet = (sender as Button).Text;
            next_op = true;
        }

        private void button_numerals_Click(object sender, EventArgs e)
        {
            //---------- K�vetkez� operandus fogad�sa, nem szignifik�ns null�k sz�r�se
            if (next_op || kijelzo.Text=="0"  && (sender as Button).Text!=tizedesjel)
               { 
                  kijelzo.Text=(sender as Button).Text!=tizedesjel?"":"0";
                  next_op=false;
               }

            if (kijelzo.Text.Length<10)
               kijelzo.Text += (sender as Button).Text;
        }

        private void button_separator_Click(object sender, EventArgs e)
        {
            if (kijelzo.Text.IndexOf(tizedesjel)==-1)
            {
               button_numerals_Click(sender,e);
            }
        }

        //-------------- Billenty�le�t�s figyel�se �s �tir�ny�t�sa
        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {

            //---------- Gomb t�mbindex�nek meghat�roz�sa
            int pos = felirat.IndexOf(e.KeyChar.ToString());
            int o = pos%oszlop;
            int s = pos/oszlop;

            //---------- Esem�nyekezel� elj�r�sok megh�v�sa
            if ((tizedesjel).IndexOf(e.KeyChar.ToString()) > -1)
            {
                this.button_separator_Click((Button)gombok[o,s],(e as EventArgs));
            }

            if (("0123456789").IndexOf(e.KeyChar.ToString()) > -1)
            {
                this.button_numerals_Click((Button)gombok[o,s],(e as EventArgs));
            }

            else if ("+-*/^=".IndexOf(e.KeyChar.ToString()) > -1)
            {
                this.button_operations_Click((Button)gombok[o,s],(e as EventArgs));
            }

            else if ("�".IndexOf(e.KeyChar.ToString()) > -1)
            {   // Alt 0177 
                this.button_sign_Click((Button)gombok[o,s],(e as EventArgs));
            }

            else if ("C".IndexOf(e.KeyChar.ToString()) > -1)
            {
                this.button_c_Click((Button)gombok[o,s],(e as EventArgs));
            }
            else if ("P".IndexOf(e.KeyChar.ToString()) > -1)
            {
                this.button_off_Click((Button)gombok[o,s],(e as EventArgs));
            }
        }
    }

    //================== F�PROGRAM
    static class Program
    {
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}