/*
 * Csigaverseny:
 * 
 *    H�rom PictureBox-ban indul� csiga  v�letlensz�m-gener�torral megadott t�vols�gokat tesz meg.
 *    A verseny a fogad�s megt�tel�vel (RadioButton) indul, �s a  ClientSize.Width el�r�sekor �r v�get.
 *    Az eredm�ny �s a fogad�s ki�rt�kel�se a Form c�msor�ban jelenik meg.
 *    
 *    2012.03.25 fj
 * 
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;


//===================================== Program.cs
namespace csiga
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}


//===================================== Form1.cs
namespace csiga
{
    public partial class Form1 : Form
    {
        Random r;                       // Mozg�s modellez�s�hez
        int mozog = 50;                 // Csiga maximum mennyit mozog egy �temben
        bool vege = false;              // Eredm�ynhirdet�s ut�n ne induljon m�g egyszer
        
        struct sresult                  // Eredm�ny ki�rt�kel�s�hez
        {
            public string nev;
            public int pos;
            public bool fogad;
        }

        //============================= Form inicializ�l�sa
        public Form1()
        {
            InitializeComponent();
            r = new Random();

            pictureBox1.BackColor = Color.Transparent;
            pictureBox2.BackColor = Color.Transparent;
            pictureBox3.BackColor = Color.Transparent;
        }

        //============================= Timer m�veletek
        private void timer1_Tick(object sender, EventArgs e)
        {
            //------------------------- Versenyv�ge figyel�s
            // Ha a hat�r�tl�p�st nem akarjuk, akkor => pictureBox1.Left + pictureBox1.Width + mozog
            if (pictureBox1.Left + pictureBox1.Width >= ClientSize.Width ||
                pictureBox2.Left + pictureBox2.Width >= ClientSize.Width ||
                pictureBox3.Left + pictureBox3.Width >= ClientSize.Width)
            {
                timer1.Stop();
                vege = true;

                //--------------------- Eredm�ny ki�rt�kel�se
                sresult[] helyezes = new sresult[3];

                helyezes[0].nev = radioButton1.Text;
                helyezes[1].nev = radioButton2.Text;
                helyezes[2].nev = radioButton3.Text;

                helyezes[0].pos = pictureBox1.Left + pictureBox1.Width;
                helyezes[1].pos = pictureBox2.Left + pictureBox2.Width;
                helyezes[2].pos = pictureBox3.Left + pictureBox3.Width;


                helyezes[0].fogad = radioButton1.Checked;
                helyezes[1].fogad = radioButton2.Checked;
                helyezes[2].fogad = radioButton3.Checked;


                //--------------------- Eredm�ny rendezese
                int max_idx;
                sresult xhely = new sresult();

                for (int i = 0; i < helyezes.Length-1; i++)
                {
                    max_idx=i;
                    for (int j = i+1; j < helyezes.Length; j++)
                    {
                        if (helyezes[max_idx].pos < helyezes[j].pos) max_idx = j;
                    }
                    if (max_idx != i)
                    {
                        xhely = helyezes[i];
                        helyezes[i] = helyezes[max_idx];
                        helyezes[max_idx] = xhely;
                    }
                }

                //--------------------- Eredm�ny ki�r�sa a form c�msor�ba
                string nyert = helyezes[0].fogad?"-> �n NYERT":"-> �n NEM nyert" ;
                this.Text += " eredm�ny:   1." + helyezes[0].nev + "   2." + helyezes[1].nev + "   3." + helyezes[2].nev +  "   " + nyert;

                //--------------------- Aktu�lis poziciok kiiratasa
                radioButton1.Text += " (" + Convert.ToString(pictureBox1.Left + pictureBox1.Width) + ")";
                radioButton2.Text += " (" + Convert.ToString(pictureBox2.Left + pictureBox2.Width) + ")";
                radioButton3.Text += " (" + Convert.ToString(pictureBox3.Left + pictureBox3.Width) + ")";

                //--------------------- Eredm�ny napl�z�sa
                try
                {
                    System.IO.TextWriter writeFile = new System.IO.StreamWriter("result.txt", true);
                    nyert = helyezes[0].fogad ? "1" : "0";
                    writeFile.WriteLine(DateTime.Now.ToString() + ";" + helyezes[0].nev + ";" + helyezes[1].nev + ";" + helyezes[2].nev+ ";" + nyert);
                    writeFile.Close();
                    writeFile = null;
                }
                catch (System.IO.IOException ex)
                {
                    MessageBox.Show(ex.ToString());
                }
            }
            else  //------------------- csig�k mozgat�sa
            {
                pictureBox1.Left += r.Next(mozog);
                pictureBox2.Left += r.Next(mozog);
                pictureBox3.Left += r.Next(mozog);
            }
        }

        //============================== Fogad�s �s a verseny ind�t�sa
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if(!vege) timer1.Start();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (!vege) timer1.Start();
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            if (!vege) timer1.Start();
        }
    }
}

//===================================== Form1.Designer.cs
namespace csiga
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.DarkOliveGreen;
            //this.pictureBox1.Image = global::csiga.Properties.Resources.csiga1v;
            this.pictureBox1.Image = Image.FromFile(Environment.GetEnvironmentVariable("cslhome")+"pictures\\csiga1v.png");
            this.pictureBox1.Location = new System.Drawing.Point(77, 32);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(80, 60);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.DarkOliveGreen;
            //this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Image = Image.FromFile(Environment.GetEnvironmentVariable("cslhome")+"pictures\\csiga2v.png");
            this.pictureBox2.Location = new System.Drawing.Point(77, 98);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(80, 60);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.DarkOliveGreen;
            //this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Image = Image.FromFile(Environment.GetEnvironmentVariable("cslhome")+"pictures\\csiga3v.png");
            this.pictureBox3.Location = new System.Drawing.Point(77, 164);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(80, 60);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.BackColor = System.Drawing.Color.Transparent;
            this.radioButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.radioButton1.ForeColor = System.Drawing.Color.Orange;
            this.radioButton1.Location = new System.Drawing.Point(6, 56);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(52, 21);
            this.radioButton1.TabIndex = 3;
            this.radioButton1.Text = "Red";
            this.radioButton1.UseVisualStyleBackColor = false;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.BackColor = System.Drawing.Color.Transparent;
            this.radioButton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.radioButton2.ForeColor = System.Drawing.Color.Orange;
            this.radioButton2.Location = new System.Drawing.Point(6, 118);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(66, 21);
            this.radioButton2.TabIndex = 4;
            this.radioButton2.Text = "Green";
            this.radioButton2.UseVisualStyleBackColor = false;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.BackColor = System.Drawing.Color.Transparent;
            this.radioButton3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.radioButton3.ForeColor = System.Drawing.Color.Orange;
            this.radioButton3.Location = new System.Drawing.Point(6, 186);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(54, 21);
            this.radioButton3.TabIndex = 5;
            this.radioButton3.Text = "Blue";
            this.radioButton3.UseVisualStyleBackColor = false;
            this.radioButton3.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.OliveDrab;
            //this.BackgroundImage = global::csiga.Properties.Resources.hatter;
            this.BackgroundImage = Image.FromFile(Environment.GetEnvironmentVariable("cslhome")+"pictures\\hatter.png");
            this.ClientSize = new System.Drawing.Size(741, 262);
            this.Controls.Add(this.radioButton3);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Csigaverseny";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton3;
    }
}
