/* 
 * K�sz�ts�nk AKNAKERES� j�t�kot, ahol egy N � M m�ret� m�trixba kell 
 * K darab akn�t elhelyezni. Az akn�k elhelyez�s�nek szab�lyai:
 * � ne tegy�nk k�tszer ugyanarra a helyre akn�t, hogy a K darab akna a 
 *   ter�leten fellelhet� legyen K k�l�nb�z� cell�ban,
 * � az akn�k oldalukkal, sarkukkal szomsz�dos cell�kba is ker�lhetnek,
 * � az akn�k a m�trix sz�ls� cell�iba is ker�lhetnek
 * A j�t�kter�letet fut�sidej� komponensek haszn�lat�val kezelj�k.
 *
 * 2012.10.29 fj
 *
 */

using System;
using System.Globalization;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;

namespace minesweeper
{
    //================== Form1 oszt�ly
    public class Form1 : Form
    {
        //-------------- Vez�rl�k be�ll�t�si adatai
        //private const int oszlop = 20, sor = 16, meret=30 , k=oszlop*sor/10;
        private const int oszlop = 18, sor = 10, meret=30 , k=oszlop*sor/10;
        private Button[,] gombok = new Button[oszlop, sor];

        //-------------- Tesztel�s - Demo
        private bool test = true;  //-------- Szomsz�dos akn�k sz�ma megjelenjen-e?

        //-------------- J�t�k �llapotfigyel�s
        private string frmtxt = "MineSweeper";
        private int clickcount=0;
        private int exposecount=0;
        private DateTime starttime = DateTime.Now;
        private System.Windows.Forms.Timer gametime = new System.Windows.Forms.Timer();

        //-------------- Form1 p�ld�nyos�t�s
        public Form1()
        {
            InitializeComponent();
            InitializeMines();
        }

        //-------------- Form inicializ�l�sa
        private void InitializeComponent()
        {
            this.SuspendLayout();

            //---------- Timer a j�t�kid� figyel�s�hez
            this.gametime.Interval=1000;
            this.gametime.Tick += new System.EventHandler(this.gametime_Tick);
            this.gametime.Enabled = true;


            //---------- Gombok t�mb felt�lt�se �s elemtulajdons�gai
            for (int i = 0; i < oszlop; i++)
                for (int j = 0; j < sor; j++)
                {
                    //------- Gombok l�trehoz�sa fut�sid�ben 
                    this.gombok[i, j ] = new System.Windows.Forms.Button();
                    //this.gombok[i, j ].FlatStyle = System.Windows.Forms.FlatStyle.System;
                    this.gombok[i, j ].BackColor = System.Drawing.SystemColors.ButtonFace;
                    this.gombok[i, j ].FlatAppearance.BorderSize = 3;
                    //this.gombok[i, j ].ForeColor = System.Drawing.SystemColors.ButtonFace;
                    this.gombok[i, j ].Font = new System.Drawing.Font("Microsoft Sans Serif", meret/3, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
                    this.gombok[i, j ].Name = Convert.ToString(i + j * oszlop);
                    //this.gombok[i, j ].Text = Convert.ToString(i + j * oszlop);
                    this.gombok[i, j ].Tag = " ";
                    this.gombok[i, j ].TabIndex = i + j * oszlop;
                    this.gombok[i, j ].Location = new System.Drawing.Point(i*meret, j*meret);
                    this.gombok[i, j ].Size = new System.Drawing.Size(meret, meret);

                    //------- Esem�nykezel�s
                    this.gombok[i, j ].Click += new System.EventHandler(this.button_Click);

                    this.Controls.Add(gombok[i, j]);
                }

            //---------- Form1 tulajdons�gai

            if (test) frmtxt +=" | Demo";

            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightGray;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.ClientSize = new System.Drawing.Size(oszlop * meret, sor*meret);
            this.Name = "Form1";
            this.Text = frmtxt;
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        //-------------- Akn�k telep�t�se
        private void InitializeMines()
        {
            Random rnd = new Random();
            int akna = 0;

            for (int i=0; i<k;i++)
            {  
               do
               {      
                  akna = rnd.Next(oszlop*sor);
               }
               while (gombok[akna%oszlop,akna/oszlop].Tag.Equals("*")); 
 
                 //----- Tesztel�skor a poz�ci�k ellen�rz�se
                 //  MessageBox.Show(Convert.ToString(akna)+":"
                 //  +Convert.ToString(akna%oszlop)+","
                 //  +Convert.ToString(akna/oszlop));
              
               gombok[akna%oszlop,akna/oszlop].Tag="*";
               gombok[akna%oszlop,akna/oszlop].Font = new System.Drawing.Font("Microsoft Sans Serif", meret/2, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            }

            //---------- Aknasz�ml�l�s
            for (int o = 0; o < oszlop; o++)
                for (int s = 0; s < sor; s++)
                {
                   if (!gombok[o,s].Tag.Equals("*"))
                   {
                       gombok[o,s].Tag = Convert.ToString(minenumber(o,s));

                       //------- Tesztel�shez a feliratok bekapcsol�sa --------
                         if (test) gombok[o,s].Text = (string)gombok[o,s].Tag;
                       //------------------------------------------------------
                   }
                }
        }

        //-------------- Szomsz�dos akn�k sz�mol�sa
        private int minenumber(int o, int s)
        {
           int aknadb=0;
           for (int i=o-1;i<=o+1;i++)
               if (i>=0 && i<oszlop)
                  for (int j=s-1;j<=s+1;j++)
                      if (j>=0 && j<sor && gombok[i,j].Tag.Equals("*")) aknadb++;

           return aknadb;
        }

        //============== Timer esem�nyek kezel�se ==============
        private void gametime_Tick(object sender, EventArgs e)
        {
            this.Text = frmtxt+" | Mine: "+k.ToString()+" | Exp: "+exposecount.ToString()
                      +" | Click: "+clickcount.ToString()+" | Time: "
                      +(DateTime.Now-starttime).ToString("mm\\:ss");
        }

        //============== Gombesem�nyek kezel�se ==============
        private void button_Click(object sender, EventArgs e)
        {
            //---------- J�t�k �llapot ki�r�s
            clickcount++;
            gametime_Tick(sender,e);

            //---------- Akn�kkal nem szomsz�dos mez�
            if ((sender as Button).Tag.Equals("0"))
            {
                 // fest�s

                 //  MessageBox.Show((sender as Button).Name+","
                 //  +Convert.ToString(Convert.ToInt32((sender as Button).Name)%oszlop)+","
                 //  +Convert.ToString(Convert.ToInt32((sender as Button).Name)/oszlop));

                 befest(Convert.ToInt32((sender as Button).Name)%oszlop,Convert.ToInt32((sender as Button).Name)/oszlop);
                 gametime_Tick(sender,e); //--- v�ltozhat az �llapot
            }

            //---------- Aknafog�s GAME OVER
            else if ((sender as Button).Tag.Equals("*"))
            { 
               gameover("GAME OVER");

               (sender as Button).BackColor=System.Drawing.Color.Red;
            }

            //---------- Akn�kkal szomsz�dos mez�k felt�r�sa
            else 
            {
               feltar(sender as Button);
               gametime_Tick(sender,e); //--- v�ltozhat az �llapot
            }

            //---------- Gy�zelem VICTORY
            if (exposecount==(oszlop*sor-k)) 
            {               
               gameover("VICTORY");
            }

        }

        //-------------- befest -------------- A L�NYEG !!!
        // Forr�s: http://aries.ektf.hu/~hz/pdf-tamop/pdf-02/download/csharp-gyak.pdf
        //

        private void befest(int x, int y)
        {
           if (!gombok[x,y].Tag.Equals("0")) return;

           //----------- Aktu�lis gomb felt�r�sa
           //A Tag space legyen, mert blank eset�n a hat�rol� gombokn�l m�gegyszer felt�r !!!
           //
           gombok[x,y].Tag=" ";  //--------------- Fontos!!!
           //
           feltar(gombok[x,y] as Button);

           //----------- Hat�rol� gombok felt�r�sa
           for (int i=x-1;i<=x+1;i++)
               if (i>=0 && i<oszlop)
                  for (int j=y-1;j<=y+1;j++)
                      if (j>=0 && j<sor && ("12345678").IndexOf(gombok[i,j].Tag.ToString())>-1)
                      {
                         feltar(gombok[i,j] as Button);
                      }

           //----------- Rekurz�v h�v�sok
           if (x>0) befest(x-1,y);
           if (x<oszlop-1) befest (x+1,y);
           if (y>0) befest(x,y-1);
           if (y<sor-1) befest (x,y+1);
        }

        //-------------- feltar
        private void feltar(Button gomb)
        {
            gomb.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            gomb.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            gomb.BackColor=System.Drawing.Color.LightBlue;
            gomb.Text = (string)gomb.Tag;
            gomb.Enabled = false;
            gomb.Tag = "X";    //------- A befest� algoritmus miatt fontos!!!

            exposecount++;
        }

        //-------------- gameover
        private void gameover(string go)
        {
            this.gametime.Enabled = false;
            this.Text += " - "+go;
            for (int i = 0; i < oszlop; i++)
                for (int j = 0; j < sor; j++)
                {
                   gombok[i, j ].Click -= new System.EventHandler(this.button_Click);

                   if (gombok[i, j ].Tag.Equals("*"))
                   { 
                      feltar(gombok[i, j]); 

                      gombok[i, j].BackColor=System.Drawing.Color.LightYellow;
                      gombok[i, j].ForeColor=System.Drawing.Color.Red;
                   }
                }
        }

    } //--- End of Class form1

    //================== F�PROGRAM
    static class Program
    {
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    } //--- End of Class Program

} //--- End of Namespace minesweeper