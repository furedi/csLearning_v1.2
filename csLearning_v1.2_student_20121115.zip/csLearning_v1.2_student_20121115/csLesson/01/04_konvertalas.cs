using System;
public class Program
{ 
   static public void Main()
   {
      byte x = 10;

      // A konsolra karaktersorozatot �rathatunk ki !

      Console.WriteLine(Convert.ToString(x, 2));  // 1010
 
      int y = 10;
      Console.WriteLine(Convert.ToString(x, y));  // 10
      Console.WriteLine(x.ToString());

      char z = 'a';
      Console.WriteLine(Convert.ToString(z, 2));  // 1100001
      Console.WriteLine(Convert.ToString(z, 16)); // 61 
      Console.WriteLine(Convert.ToString(z, 10)); // 97
   }
}