/*
 * Olvasson be egy nevet, majd irassa ki
 * a nev hosszat, 
 * a nev betuit ford�tott sorrendben,
 * a nev karaktereit l�pcsozetesen,
 * a nevben szereplo karaktereket abc-ben.
 */

using System;
using System.Collections.Generic;

class szoveg
{
   static void Main()
   {
      string nev;

      Console.WriteLine("String objektum kezel�se");

      Console.WriteLine("\nKerek egy nevet:");
      nev=Console.ReadLine();

      //----------- karakterek szama
      Console.WriteLine("\nA bet�k sz�ma: {0}",nev.Length);

      //-----------
      Console.WriteLine("\nN�v bet�i ford�tott sorrendben:");
      for (int i=nev.Length-1;i>=0;i--)
      {
         Console.Write(nev[i]);
      }
      Console.WriteLine();  //--- soremel�s

      //-----------
      Console.WriteLine("\nA n�v karakterei lepcs�zetesen:");
      for (int i=1;i<=nev.Length;i++)
      {
         Console.WriteLine(nev.Substring(0,i));
      }

      //-----------
      Console.WriteLine("\nN�vben szerepl� karakterek ABC-ben:");

      SortedSet<char> karak = new SortedSet<char>();

      foreach (char c in nev)
      {
         karak.Add(c);
      }

      foreach (char c in karak) Console.Write("{0}, ",c);
      Console.WriteLine();

      Console.Write("\nK�rem nyomja le az ENTER-t");
      Console.ReadLine();
   }
}