//vektor.cs
using System;
class vektorpelda
{
   public static void Main()
   {
   // Sima vektordefin�ci�, a defin�ci� pillanat�ban
   // 5 elem� vektor lesz
   // A vektorelemeknek k�l�n nem adtunk kezd��rt�ket,
   // ez�rt azok 0 �rt�ket kapnak.
   int[] numbers = new int[5];
   // K�tdimenzi�s vektor, sima 5x4-es sz�veges,
   //ezen elemek inicializ�l�s hi�ny�ban null �rt�ket kapnak.
   string[,] names = new string[5,4];
   // Vektorok vektora, ezt az irodalom gyakran
   //"jagged array", (csipk�s, szaggatott vektor) n�ven eml�ti
   byte[][] scores = new byte[5][];

   // Az egyes vektorok defini�l�sa
   for (int i = 0; i < scores.Length; i++)
   {
      scores[i] = new byte[i+3]; // elemr�l elemre n� az elemsz�m.
   }
   
   // Egyes sorok hossz�nak ki�r�sa
   for (int i = 0; i < scores.Length; i++)
   {
      // A {} jelek k�z�tti sz�mmal hivatkozhatunk az els� param�ter
      // ut�ni tov�bbi �rt�kekre. {0} jelenti az i v�ltoz�t.
      // Haszn�lata nagyon hasonl�t a C printf haszn�lat�hoz.
      
      Console.WriteLine("Az {0} sor hossza: {1}", i, scores[i].Length);

   }

   }
}