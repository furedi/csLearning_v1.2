using System;
public class Program
{
   static public void Main()
   { 
       object a = "123";
       object b = "Hello";
       object c = 10;

       string aa = a as string;
       Console.WriteLine(aa == null ? "NULL" : aa); // 123

       string bb = b as string;
       Console.WriteLine(bb == null ? "NULL" : bb); // Hello

       string cc = c as string;
       Console.WriteLine(cc == null ? "NULL" : cc); // NULL
   }
}

