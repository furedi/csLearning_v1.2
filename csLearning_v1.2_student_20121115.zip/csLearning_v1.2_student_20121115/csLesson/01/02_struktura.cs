using System;
struct strukt�ra_p�lda
{
   public int kor;
   public string n�v;
}
class strukt�ra_haszn�l
{
   public static void Main()
   {
      strukt�ra_p�lda sp=new strukt�ra_p�lda();
      sp.kor=5;
      sp.n�v="�va";

      // strukt�ra_p�lda vektor
      strukt�ra_p�lda [] spv=new strukt�ra_p�lda[5];
      int i=0;
      // beolvas�s
      while(i<3)
      {
          spv[i]=new strukt�ra_p�lda();
          Console.WriteLine("\nK�rem az {0}. elem nev�t!",i);
          string n=Console.ReadLine();
          spv[i].n�v=n;
          Console.WriteLine("K�rem az {0}. elem kor�t!",i);
          n=Console.ReadLine();
          spv[i].kor=Convert.ToInt32(n);
          i++;
      }
      Console.WriteLine("\r\nBeolvasott adatok:");
      // ki�r�s
      for(i=0;i<3;i++)
      {
         Console.WriteLine(spv[i].n�v);
         Console.WriteLine(spv[i].kor);
      }
   Console.WriteLine("\nK�rem nyomja le az ENTERT-t");
   Console.ReadLine();
   }
}
