﻿/* 
 * ============================================================================
 * csLearning v1.2 C# oktató programocska
 * ============================================================================
 * A keretprogram a programozás tanítás bevezető szakaszában nyújt interaktív
 * segítséget az alapfogalmak, változók, vezérlőszerkezetek és programozási
 * tételek megismerésében. Továbbá bemutatja az OOP során használatos osztályok
 * kezelését, és néhány bemutatóprogram erjéig kitekint a Windows alkalmazások
 * lehetőségeire.
 * 
 * Működés feltétele a .NET keretrendszer telepítése és a csc.exe compiler
 * elérési útjának beállítása a PATH környezeti változóban.
 * 
 * A csLearning keretproram létrehoz egy "cslhome" környezeti változót, ami
 * mindig az aktuális lecke munkakönyvtárára mutat, és így a mintaprogramokban
 * könnyen elérhetővé válnak a külső fájlokban lévő adatok vagy képek. Például:
 * filePath = Environment.GetEnvironmentVariable("cslhome")+"pictures\\pic.jpg"
 * 
 * A kezelt tananyag szabadon módosítható és bővíthető a felhasználó igényei
 * szerint.
 * 
 * Készítés dátuma: 2011 december - 2012 április
 * 
 * Konzulens: Lipovits Ágnes
 * 
 * Készítette: Füredi János ITMA hallgató
 * 
 * ============================================================================
 */
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using System.Globalization;

namespace csLearning
{
    public partial class Form1 : Form
    {
        //--------------------------------------- Elérési utak
        public string tmpdir;       // Ideiglenes állományok könyvtára
        public string tmpfile;      // Ideiglenes állományok neve
        public string cscdir;       // Compiler elérési útja
        public string workdir;      // Lessons munkakönyvtár => cslhome környezeti változó
        public Font tbfont;         // Textbox betűjellemzők

        //======================================= Form1
        public Form1()
        {
            InitializeComponent();

            tbfont = textBox1.Font; // textBox1.Font kezdőérték elmetése;

            //----------------------------------- Ideiglenes állományok elérési utja
            tmpdir = Environment.GetEnvironmentVariable("TMP");
            if (tmpdir == "") tmpdir = Directory.GetCurrentDirectory();

            //----------------------------------- Az ideiglenes forrásfájl neve
            tmpfile = "csprogram";  

            cscdir = "";            // csc.exe elérési útja
            if (Environment.GetEnvironmentVariable("PATH").IndexOf(@"\Windows\Microsoft.NET\Framework") == -1)
            {
                //------------------------------- A telepített .NET verzió megkeresése
                string[] dirs = Directory.GetDirectories(@"C:\Windows\Microsoft.NET\Framework\", "v?.*");
                Array.Sort(dirs);
                cscdir = dirs[dirs.Length - 1];
                if (cscdir != "")
                {
                    //--------------------------- Üzenet a PATH beálítására figylemeztet
                    //Például: "PATH = %PATH%;c:\Windows\Microsoft.NET\Framework\v4.0.30319"
                    MessageBox.Show("Kérem állítsa be a csc.exe elérési útját a PATH kötnyezeti változóban:\r\n\n"
                                    + @"PATH = %PATH%;" + cscdir);
                    cscdir += "//"; // Az elérési út és a compiler neve közé kell a backslash !
                }
                else
                {
                    //------------------------------- cscdir.cfg fájlba beállított elérési út átvétle
                    using (StreamReader sr = new StreamReader("cscdir.cfg", Encoding.Default))
                    {
                        string line;
                        while ((line = sr.ReadLine()) != null)
                        {
                            if (line.IndexOf(@"\Windows\Microsoft.NET\Framework") != -1) cscdir = line + "//";
                        }
                    }
                }
            }

            //----------------------------------- Leckecímek feltöltése
            // csLession könvtár alkönyvtárai 00, 01, 02 ...
            // index__.html file <title>leckecím</title>
            leckeinfo(Environment.CurrentDirectory + @"\csLesson\");

            // http://msdn.microsoft.com/en-us/library/system.windows.forms.combobox.aspx
            toolStripComboBox1.SelectedIndex = 0;
            toolStripLabel1.Visible = false;

            this.Width = 1080; //+= 400;
            this.Height = 720; //+= 200;
        }

        //======================================= Környezeti változó, munkaállományok törlése
        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Environment.SetEnvironmentVariable("cslhome", null);

            try
            {
                // Ha nem fut a saját process akkor kitorli a munkaállományokat
                if (Process.GetProcessesByName(tmpfile).Length == 0)
                {
                    if (File.Exists(tmpdir + "//"+tmpfile+".cs"))
                    {
                        File.Delete(tmpdir + "//" + tmpfile + ".cs");
                    }
                    if (File.Exists(tmpdir + "//" + tmpfile + ".exe"))
                    {
                        File.Delete(tmpdir + "//" + tmpfile + ".exe");
                    }
                }
                    textBox2.Text = "Goodbye for the present!";
            }
            catch (IOException ex)
            {
                    MessageBox.Show(ex.Message);
            }
            Close();
        }

        //======================================= Leckecímek begyűjtése
        private void leckeinfo(string path)
        {
            // Forrás: http://msdn.microsoft.com/en-us/library/6ff71z1w.aspx
            try
            {
                toolStripComboBox1.Items.Clear();
                //------------------------- leckekönyvtárak felolvasása
                string[] dirs = Directory.GetDirectories(path);
                Array.Sort(dirs);
                string htmlfile = "";
                string htmlkod = "";
                foreach (string dir in dirs)
                {
                     // index__.html első <title> sorából a leckecím kiolvasása
                    htmlfile = dir+ @"\index" + dir.Remove(0, path.Length) + ".html";
                    using (StreamReader sr = new StreamReader(htmlfile, Encoding.Default))
                    {
                         htmlkod=sr.ReadToEnd();
                         toolStripComboBox1.Items.Add(htmlkod.Substring(htmlkod.IndexOf("<title>")+7, htmlkod.IndexOf("</title>") - htmlkod.IndexOf("<title>")-7));
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("The process failed: {0}", ex.ToString());
            }

        }
        //======================================= Lecke betöltés
        private void toolStripComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            workdir = Environment.CurrentDirectory + @"\csLesson\"
                    + String.Format(@"{0,2:00}\", toolStripComboBox1.SelectedIndex);

            //------------------------- cslhome környezeti változó beállítása a forráskódok hivatkozásaihoz
            Environment.SetEnvironmentVariable("cslhome", workdir);
            //MessageBox.Show(Environment.GetEnvironmentVariable("cslhome"));

            webBrowser1.Navigate(new Uri(workdir
                + "index" + String.Format(@"{0,2:00}", toolStripComboBox1.SelectedIndex) + ".html"));

            forrasinfo(workdir);
        }

        //======================================= Előző lecke
        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            if (toolStripComboBox1.SelectedIndex > 0) toolStripComboBox1.SelectedIndex--;
        }

        //======================================= Következő lecke
        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            if (toolStripComboBox1.SelectedIndex < toolStripComboBox1.Items.Count - 1) toolStripComboBox1.SelectedIndex++;
        }


        //======================================= Forráskódnevek begyüjtése
        private void forrasinfo(string path)
        {
            // Forrás: http://msdn.microsoft.com/en-us/library/ms143448.aspx
            DirectoryInfo dir = new DirectoryInfo(path);
            FileInfo[] files = dir.GetFiles("*.cs", SearchOption.TopDirectoryOnly);

            toolStripComboBox2.Items.Clear();
            foreach (FileInfo file in files)
            {
                toolStripComboBox2.Items.Add(file.Name);
            }
            toolStripComboBox2.Sorted = true;

            if (toolStripComboBox2.Items.Count > 0)
            {
                toolStripComboBox2.SelectedIndex = 0;
                forraskod(path + toolStripComboBox2.SelectedItem);
            }
        }

        //======================================= Forráskod betöltés
        private void forraskod(string forrasnev)
        {
            try
            {
                textBox1.Clear();
                textBox2.Clear();

                // Create an instance of StreamReader to read from a file.
                // The using statement also closes the StreamReader.
                // http://stackoverflow.com/questions/5640975/setting-textbox-encoding-in-windows-forms

                using (StreamReader sr = new StreamReader(forrasnev, Encoding.Default))
                {

                    //----------------- Forráskod betöltése egyszerre, ötlet Csatlós László
                    
                    textBox1.Text = sr.ReadToEnd();

                    //----------------- Forráskod betöltése soronként
                    /*
                    string line;
                    // Read and display lines from the file until the end of the file is reached.
                    while ((line = sr.ReadLine()) != null)
                    {
                        textBox1.Text += line + "\r\n";
                        //Console.WriteLine(line);
                    }
                    */
                   
                }
            }
            catch (Exception ex)
            {
                // Let the user know what went wrong.
                MessageBox.Show("The file could not be read: " + ex.Message);
            }
        }

        //======================================= Választott forráskód betöltése
        private void toolStripComboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            forraskod(workdir + toolStripComboBox2.SelectedItem);
        }

        //======================================= Előző forráskód
        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            if (toolStripComboBox2.SelectedIndex > 0) toolStripComboBox2.SelectedIndex--;
        }

        //======================================= Következő forráskód
        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            if (toolStripComboBox2.SelectedIndex < toolStripComboBox2.Items.Count - 1) toolStripComboBox2.SelectedIndex++;
        }

        //======================================= Forráskód mentése
        // Ikonok: http://www.iconarchive.com/
        private void toolStripButton7_Click(object sender, EventArgs e)
        {
            // Forrás: http://msdn.microsoft.com/en-us/library/sfezx97z.aspx
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            saveFileDialog1.Filter = "C# Source|*.cs";
            saveFileDialog1.Title = "Save an C# Source File";
            saveFileDialog1.OverwritePrompt = true;
            saveFileDialog1.InitialDirectory = workdir;
            //saveFileDialog1.ShowDialog();

            // Forrás: http://social.msdn.microsoft.com/Forums/en-US/vssmartdevicesvbcs/thread/7736efd7-d938-4dc7-a47f-f0e9bde2ef3f
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {

                //using (StreamWriter sw = new StreamWriter(saveFileDialog1.FileName)

                if (File.Exists(saveFileDialog1.FileName)) File.Delete(saveFileDialog1.FileName);

                //------------------------------- Az átkódolásra figyelni kell a mentéskor is (!)
                FileStream fs = new FileStream(saveFileDialog1.FileName,
                    FileMode.CreateNew, FileAccess.Write, FileShare.None);

                using (StreamWriter sw = new StreamWriter(fs, System.Text.Encoding.Default))
                {
                    sw.Write(textBox1.Text);

                    sw.Flush();
                    sw.Close();
                }

                forrasinfo(workdir);
                toolStripComboBox2.SelectedIndex =
                    toolStripComboBox2.Items.IndexOf(saveFileDialog1.FileName.Remove(0, workdir.Length));
            }

        }

        //======================================= Átkodoló a standard outputhoz (!)
        // Forrás: http://subversion.assembla.com/svn/mistral-framework/trunk/src/Core/Mistral.Framework/Utils/ProcessCaller.cs

        private string atkodolo(string str, Encoding encodingSrc)
        {
            Encoding encodingOem = Encoding.GetEncoding(CultureInfo.CurrentCulture.TextInfo.OEMCodePage);
            Encoding encodingAnsi = Encoding.GetEncoding(CultureInfo.CurrentCulture.TextInfo.ANSICodePage);
            byte[] bytesSrc = encodingSrc.GetBytes(str);
            byte[] bytesConverted = Encoding.Convert(encodingSrc, encodingAnsi, bytesSrc);
            
            return encodingOem.GetString(bytesConverted);
        }

        //======================================= Fordítás és Futtatás
        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            toolStripButton2.Enabled = false;

            // Forrás: http://msdn.microsoft.com/en-us/library/system.diagnostics.process.beginoutputreadline.aspx
            
            //string tmpkdir = Environment.GetEnvironmentVariable("TMP");
            using (StreamWriter writer = new StreamWriter(tmpdir + "//"+tmpfile+".cs"))
            {
                writer.Write(textBox1.Text);
                writer.Flush();
            }

            Process myProcess = new Process();
            Process compiler = new Process();
            //----------------------------------- Fordítás
            compiler.StartInfo.CreateNoWindow = true;
            compiler.StartInfo.FileName = cscdir+"csc.exe";
            compiler.StartInfo.WorkingDirectory = tmpdir;
            //compiler.StartInfo.Arguments = "/r:System.dll /out:sample.exe stdstr.cs";

            // Console Application vagy Windows Application fordítása 
            if (textBox1.Text.IndexOf("Application.Run") == -1)
                compiler.StartInfo.Arguments = tmpfile+".cs";
            else
                compiler.StartInfo.Arguments = "/t:winexe " + tmpfile + ".cs";

            compiler.StartInfo.UseShellExecute = false;
            compiler.StartInfo.RedirectStandardOutput = true;
            compiler.StartInfo.StandardOutputEncoding = Encoding.Default;

            compiler.Start();
            compiler.WaitForExit();

            textBox2.Text = atkodolo(compiler.StandardOutput.ReadToEnd(), compiler.StandardOutput.CurrentEncoding);
            textBox2.ForeColor = Color.Red;

            //----------------------------------- futtatás
            if (compiler.ExitCode == 0)
            {
                textBox2.ForeColor = SystemColors.WindowText;
                if (textBox1.Text.IndexOf("Console.Read") == -1 && textBox1.Text.IndexOf("Application.Run") == -1)
                {
                    myProcess.StartInfo.CreateNoWindow = true;
                    myProcess.StartInfo.FileName = tmpdir + "//"+tmpfile+".exe";
                    myProcess.StartInfo.WorkingDirectory = tmpdir;
                    myProcess.StartInfo.UseShellExecute = false;
                    myProcess.StartInfo.RedirectStandardOutput = true;
                    //myProcess.StartInfo.RedirectStandardInput = true;
                    myProcess.Start();

                    // C# menü: Tools / Options...
                    // Environment / International settings / Language -> Some as Microsoft Windows

                    //textBox2.Clear();
                    //textBox2.Text = myProcess.StandardOutput.ReadToEnd();

                    textBox2.Text = atkodolo(myProcess.StandardOutput.ReadToEnd(), myProcess.StandardOutput.CurrentEncoding);

                    //myProcess.WaitForExit();
                }

                else
                {

                    myProcess.StartInfo.FileName = tmpdir + "//" + tmpfile + ".exe";
                    myProcess.StartInfo.WorkingDirectory = tmpdir;

                    textBox2.Text = "Program futtatása ablakban...";

                    myProcess.Start();

                    //textBox2.Text = "";

                    //Process.Start(tmpdir + "//"+tmpfile+".exe");
                }
            }
            // else MessageBox.Show(Convert.ToString(compiler.ExitCode));

            toolStripButton2.Enabled = true;
        }

        //=======================================  textBox1 Sorszám, oszlopszám kiirás
        // Forrás: http://www.microbion.co.uk/developers/C%20position%20of%20caret.pdf
        private string cursorpos(TextBox tbMain)
        {
            //get current line
            int index = tbMain.SelectionStart;

            if (index < tbMain.Text.Length && tbMain.SelectionStart+tbMain.SelectionLength < tbMain.Text.Length)
            {
                int line = tbMain.GetLineFromCharIndex(index);

                // get the caret position in pixel coordinates
                Point pt = tbMain.GetPositionFromCharIndex(index);
                // now get the character index at the start of the line, and
                // subtract from the current index to get the column
                pt.X = 0;
                int col = index - tbMain.GetCharIndexFromPosition(pt);

                // finally, update the display in the status bar, incrementing the line and
                // column values so that the first line & first character position is shown as "1, 1"

                //return (tbMain.Text.Length).ToString() + " " + (index).ToString()+" "+
                //    (++line).ToString() + ", " + (++col).ToString();

                // <etx> jelzése
                if (line<0) MessageBox.Show(index.ToString()+" "+line.ToString()+" "+col.ToString());
                return "[ " + (++line).ToString() + ", " + (++col).ToString() + " ]";
            }
            else return "[ ETX ]";

            // return "["+(++line).ToString("D4") + ", " + (++col).ToString("D4")+"]";
            // return "[" + String.Format("{0,3}", (++line)) + ", " + String.Format("{0,3}", (++col)) + "]";
        }

        //======================================= textBox1 események a sor, oszlopszámhoz
        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            // nem biztos, hogy kell
            toolStripLabel1.Text = cursorpos(textBox1);
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {

            //----------------------------------- CTRL-A lekezelése
            if (e.Control && e.KeyCode == Keys.A)
                textBox1.SelectAll();
            //----------------------------------- F5 lekezelése
            else if
                (e.KeyCode == Keys.F5) toolStripButton2_Click(sender, e);

            //----------------------------------- CTRL + kezelése
            else if (e.Control && e.KeyCode == Keys.Add && textBox1.Font.Size < 32)
            {
                Font f = textBox1.Font;
                textBox1.Font = new Font(f.FontFamily, f.Size + 1);
            }

            //----------------------------------- CTRL - lekezelése
            else if (e.Control && e.KeyCode == Keys.Subtract && textBox1.Font.Size > 10)
            {
                Font f = textBox1.Font;
                textBox1.Font = new Font(f.FontFamily, f.Size - 1);
            }

            else if (e.Control && e.KeyCode == Keys.NumPad0)
            {
                textBox1.Font = new Font(tbfont.FontFamily, tbfont.Size);
            }
            //----------------------------------- Cursorpos kezelése
            else
                toolStripLabel1.Text = cursorpos(textBox1);
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            toolStripLabel1.Text = cursorpos(textBox1);
        }

        private void textBox1_Enter(object sender, EventArgs e)
        {
            toolStripLabel1.Visible = true;
            toolStripLabel1.Text = cursorpos(textBox1);
        }

        private void textBox1_Click(object sender, EventArgs e)
        {
            toolStripLabel1.Text = cursorpos(textBox1);
        }

        private void textBox1_KeyUp(object sender, KeyEventArgs e)
        {
            toolStripLabel1.Text = cursorpos(textBox1);
        }

        private void textBox1_MouseUp(object sender, MouseEventArgs e)
        {
            toolStripLabel1.Text = cursorpos(textBox1);
        }

        private void textBox1_Layout(object sender, LayoutEventArgs e)
        {
            toolStripLabel1.Text = cursorpos(textBox1);
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            toolStripLabel1.Visible = false;
        }
        //======================================= end of TextBox1 events

        //======================================= textBox2 események
        private void textBox2_KeyDown(object sender, KeyEventArgs e)
        {
            //----------------------------------- CTRL + kezelése
            if (e.Control && e.KeyCode == Keys.Add && textBox2.Font.Size < 32)
            {
                Font f = textBox2.Font;
                textBox2.Font = new Font(f.FontFamily, f.Size + 1);
            }

            //----------------------------------- CTRL - lekezelése
            else if (e.Control && e.KeyCode == Keys.Subtract && textBox2.Font.Size > 10)
            {
                Font f = textBox2.Font;
                textBox2.Font = new Font(f.FontFamily, f.Size - 1);
            }

            else if (e.Control && e.KeyCode == Keys.NumPad0)
            {
                textBox2.Font = new Font(tbfont.FontFamily, tbfont.Size);
            }

        }

        //======================================= Névjegy
        private void toolStripButton8_Click(object sender, EventArgs e)
        {
            MessageBox.Show("C# keretprogram és oktatóanyag\r\n\r\n"+
                            "Legutolsó módosítás: 2012.04.06\r\n\r\n"+
                            "Konzulens: Lipovits Ágnes\r\n\r\n"+
                            "Készítette: furedi.janos@hotmail.hu",
                            Form1.ActiveForm.Text+ " MS .NET 4");
        }

    } //========================================= end of class
} // ============================================ end of namespace
